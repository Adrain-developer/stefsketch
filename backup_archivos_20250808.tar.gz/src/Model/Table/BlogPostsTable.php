<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class BlogPostsTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);
        $this->setTable('blog_posts');
        $this->setPrimaryKey('id');
        $this->setDisplayField('title');
        $this->belongsTo('BlogAuthors');
        $this->belongsTo('EventTypes');
        $this->belongsTo('BlogCategories');
        $this->belongsToMany('BlogTags', [
            'foreignKey' => 'blog_post_id',
            'targetForeignKey' => 'blog_tag_id',
            'joinTable' => 'blog_posts_blog_tags',
            'saveStrategy' => 'replace' // importante: sobreescribe las etiquetas existentes
        ]);
        $this->belongsToMany('BlogSubcategories', [
            'foreignKey' => 'blog_post_id',
            'targetForeignKey' => 'blog_subcategory_id',
            'joinTable' => 'blog_posts_blog_subcategories',
            'saveStrategy' => 'replace' // importante: sobreescribe las etiquetas existentes
        ]);
        $this->addBehavior('Timestamp');
    }

    public function validationDefault(Validator $validator): Validator
{
    $validator
        ->notEmptyString('title')
        ->allowEmptyString('body'); // ahora body es siempre opcional
        
    return $validator; 
}

}
