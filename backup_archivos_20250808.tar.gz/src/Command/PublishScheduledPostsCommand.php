<?php
declare(strict_types=1);

namespace App\Command;

use Cake\Command\Command;
use Cake\Console\Arguments;
use Cake\Console\ConsoleIo;
use Cake\Console\ConsoleOptionParser;
use Cake\Datasource\ModelAwareTrait;
use Cake\I18n\FrozenTime;

/**
 * PublishScheduledPosts command.
 * 
 * Este comando busca posts con status 'publicado' que tengan una fecha programada
 * que ya haya llegado y los cambia a status 'activo' para que sean visibles al público.
 */
class PublishScheduledPostsCommand extends Command
{
    use ModelAwareTrait;

    /**
     * Hook method for defining this command's option parser.
     *
     * @see https://book.cakephp.org/4/en/console-commands/commands.html#defining-arguments-and-options
     * @param \Cake\Console\ConsoleOptionParser $parser The parser to be defined
     * @return \Cake\Console\ConsoleOptionParser The built parser.
     */
    public function buildOptionParser(ConsoleOptionParser $parser): ConsoleOptionParser
    {
        $parser = parent::buildOptionParser($parser);
        
        $parser->setDescription('Publica automáticamente los posts programados cuya fecha ha llegado.');
        
        $parser->addOption('dry-run', [
            'help' => 'Muestra qué posts se publicarían sin hacer cambios reales.',
            'boolean' => true,
            'short' => 'd',
        ]);

        return $parser;
    }

    /**
     * Implement this method with your command's logic.
     *
     * @param \Cake\Console\Arguments $args The command arguments.
     * @param \Cake\Console\ConsoleIo $io The console io
     * @return null|void|int The exit code or null for success
     */
    public function execute(Arguments $args, ConsoleIo $io)
    {
        $this->loadModel('BlogPosts');
        
        $dryRun = $args->getOption('dry-run');
        $now = FrozenTime::now();
        
        $io->out('🕒 Buscando posts programados para publicar...');
        $io->out('📅 Fecha/Hora actual: ' . $now->format('Y-m-d H:i:s'));
        
        // Buscar posts que cumplan las condiciones:
        // 1. Status = 'publicado' 
        // 2. scheduled_at no es NULL
        // 3. scheduled_at <= fecha actual
        $postsToPublish = $this->BlogPosts->find()
            ->where([
                'status' => 'publicado',
                'scheduled_at IS NOT' => null,
                'scheduled_at <=' => $now
            ])
            ->contain(['BlogAuthors']) // Para mostrar info del autor
            ->toArray();
        
        if (empty($postsToPublish)) {
            $io->success('✅ No hay posts programados para publicar en este momento.');
            return static::CODE_SUCCESS;
        }
        
        $io->out(sprintf('📝 Encontrados %d post(s) para publicar:', count($postsToPublish)));
        $io->hr();
        
        $publishedCount = 0;
        
        foreach ($postsToPublish as $post) {
            $author = $post->blog_author ? $post->blog_author->name : 'Sin autor';
            
            $io->out(sprintf(
                '📄 ID: %d | Título: "%s" | Autor: %s | Programado: %s',
                $post->id,
                $post->title,
                $author,
                $post->scheduled_at->format('Y-m-d H:i:s')
            ));
            
            if ($dryRun) {
                $io->info('   [DRY RUN] Se cambiaría status a "activo"');
            } else {
                // Cambiar status a 'activo' para que sea visible
                $post->status = 'activo';
                
                if ($this->BlogPosts->save($post)) {
                    $io->success('   ✅ Publicado exitosamente');
                    $publishedCount++;
                } else {
                    $io->error('   ❌ Error al publicar');
                    $io->err('   Errores: ' . json_encode($post->getErrors()));
                }
            }
        }
        
        $io->hr();
        
        if ($dryRun) {
            $io->info(sprintf('🧪 [DRY RUN] Se habrían publicado %d post(s)', count($postsToPublish)));
        } else {
            $io->success(sprintf('🎉 Proceso completado. Posts publicados: %d/%d', $publishedCount, count($postsToPublish)));
            
            if ($publishedCount < count($postsToPublish)) {
                $io->warning('⚠️  Algunos posts no se pudieron publicar. Revisa los logs.');
                return static::CODE_ERROR;
            }
        }
        
        return static::CODE_SUCCESS;
    }
}