<!-- Modal musica de fondo -->
<div id="modalMusica" class="modal fade show" tabindex="-1" style="padding-right: 10px; display: block;" aria-modal="true" role="dialog">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-body text-center">
        <p>

          Bienvenidos a la invitación de
          Manuela
          y
          Lauro        </p>

        <span>La música de fondo es parte de la experiencia</span>

        <br>
        <a class="boton" id="play-music-modal" >Ingresar con música</a>
        <a class="boton" data-dismiss="modal" aria-label="Close" id="" >Ingresar sin música</a>
      </div>

    </div>
  </div>
</div>
<!-- Portada -->
<section class="portada">

    <div class="d-md-flex">

        <!-- Imagen portada -->
        <div class="portada-picture"></div>

        <!-- Contenido portada -->
        <div class="portada-container d-flex justify-content-center align-items-center">


            <div class="portada-container-2">




                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo01_A.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo01_A.png">
                    <img class="adorno adorno-1 aos-init aos-animate" data-aos="fade-down" data-aos-delay="500" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo01_A.png" alt="" loading="lazy">
                </picture>

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo01_B.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo01_B.png">
                    <img class="adorno adorno-2 aos-init aos-animate" data-aos="fade-down" data-aos-delay="400" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo01_B.png" alt="" loading="lazy">
                </picture>


                <div class="row d-flex justify-content-center align-items-center">


                    <div class="content-portada text-center">

                        <!-- Idiomas -->



                        <div class="box-nombres-fecha-portada">

                            <span class="fecha">
                                15.05.2021 </span>

                            <h1>Manuel</h1>
                            <span>&amp;</span>
                            <h1>Laura</h1>

                        </div>

                        <div class="box-frase-portada">
                            <p>
                                <img src="./Boda de Manuel y Laura_files/comilla-apertura.svg" alt=""> <br>

                                Todos somos mortales, <br> hasta el primer beso y la segunda copa de vino <br>

                                <img src="./Boda de Manuel y Laura_files/comilla-cierre.svg" alt="">
                            </p>
                        </div>

                    </div>

                </div>

            </div>



        </div>

    </div>




</section>

<!-- Cuenta Regresiva -->
<section class="cuenta-regresiva">
    <div class="container">
        <div class="row d-flex justify-content-center align-items-center">

            <div class="box-aros d-flex justify-content-center align-items-center">

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_contador.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_contador.png">
                    <img class="adorno adorno-1" src="./Boda de Manuel y Laura_files/flores_contador.png" alt="">
                </picture>


                <div class="box-circulo text-center">

                    <span class="falta">Faltan</span>

                    <div id="reloj" class="reloj">

                        <div id="dias" class="reloj-col">
                            <span class="number">40</span>
                            <span class="time">días</span>
                        </div>

                        <div id="horas" class="reloj-col">
                            <span class="number">2</span>
                            <span class="time">hs</span>
                        </div>

                        <div id="minutos" class="reloj-col">
                            <span class="number">59</span>
                            <span class="time">min</span>
                        </div>

                        <div id="segundos" class="reloj-col no-border">
                            <span class="number">21</span>
                            <span class="time">seg</span>
                        </div>

                        <div class="clearfix"></div>

                    </div>


                    <div class="d-flex justify-content-center align-items-center">

                        <!-- Corazon -->
                        <div class="corazon-falta"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 32" width="38" height="32" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                                <defs>
                                    <clippath id="__lottie_element_36">
                                        <rect width="38" height="32" x="0" y="0"></rect>
                                    </clippath>
                                </defs>
                                <g clip-path="url(#__lottie_element_36)">
                                    <g transform="matrix(0.8416426181793213,0,0,0.8416426181793213,3.028989791870117,2.4781694412231445)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,18.97599983215332,16.06599998474121)">
                                            <path fill="rgb(200,167,131)" fill-opacity="1" d=" M-1.1369999647140503,15.593999862670898 C-0.7720000147819519,15.741999626159668 -0.38600000739097595,15.815999984741211 0.0010000000474974513,15.815999984741211 C0.3869999945163727,15.815999984741211 0.7730000019073486,15.741999626159668 1.1369999647140503,15.593999862670898 C1.8550000190734863,15.300999641418457 18.725000381469727,8.284000396728516 18.725000381469727,-4.073999881744385 C18.725000381469727,-10.550000190734863 13.385000228881836,-15.815999984741211 6.820000171661377,-15.815999984741211 C4.349999904632568,-15.815999984741211 1.9789999723434448,-15.067000389099121 0.0010000000474974513,-13.70199966430664 C-1.9780000448226929,-15.067000389099121 -4.348999977111816,-15.815999984741211 -6.817999839782715,-15.815999984741211 C-13.383999824523926,-15.815999984741211 -18.725000381469727,-10.550000190734863 -18.725000381469727,-4.073999881744385 C-18.725000381469727,8.284000396728516 -1.8550000190734863,15.300999641418457 -1.1369999647140503,15.593999862670898z"></path>
                                        </g>
                                    </g>
                                </g>
                            </svg></div>

                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<!-- Ceremonia - Fiesta-->
<section class="ceremonia-fiesta">




    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_A.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_A.png">
        <img class="adorno adorno-1 aos-init" data-aos="fade-right" data-aos-delay="500" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_A.png" alt="" loading="lazy">
    </picture>


    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_B.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_B.png">
        <img class="adorno adorno-2 aos-init" data-aos="fade-right" data-aos-delay="400" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_B.png" alt="" loading="lazy">
    </picture>


    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_C.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_C.png">
        <img class="adorno adorno-3 aos-init" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_C.png" alt="" loading="lazy">
    </picture>

    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_D.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_D.png">
        <img class="adorno adorno-4 aos-init" data-aos="fade-right" data-aos-delay="500" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_D.png" alt="" loading="lazy">
    </picture>



    <div class="container">
        <div class="row">

            <div class="col-md-6 col-ceremonia text-center">

                <div class="anim-anillos"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150" width="150" height="150" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                        <defs>
                            <clippath id="__lottie_element_40">
                                <rect width="150" height="150" x="0" y="0"></rect>
                            </clippath>
                        </defs>
                        <g clip-path="url(#__lottie_element_40)">
                            <g style="display: none;" transform="matrix(1,0,0,1,46.8910026550293,26.62596321105957)" opacity="0.0016004237287801004">
                                <g opacity="1" transform="matrix(1,0,0,1,15.862000465393066,18.20599937438965)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="1.69" d=" M5.723999977111816,13.821000099182129 C5.0320000648498535,13.980999946594238 4.348999977111816,13.571000099182129 3.8429999351501465,13.267999649047852 C3.746000051498413,13.208999633789062 3.6540000438690186,13.154000282287598 3.5880000591278076,13.119999885559082 C1.1929999589920044,11.869000434875488 -0.9959999918937683,10.317999839782715 -2.9170000553131104,8.51099967956543 C-3.372999906539917,8.081999778747559 -3.819999933242798,7.631999969482422 -4.247000217437744,7.172999858856201 C-7.150000095367432,4.053999900817871 -9.331000328063965,0.3230000138282776 -10.729000091552734,-3.9159998893737793 C-11.215999603271484,-5.392000198364258 -11.63700008392334,-6.964000225067139 -10.984000205993652,-8.532999992370605 C-10.770000457763672,-9.045000076293945 -10.244999885559082,-9.968999862670898 -9.12399959564209,-10.395999908447266 C-7.9720001220703125,-10.833999633789062 -6.633999824523926,-10.58899974822998 -5.252999782562256,-9.685999870300293 C-2.2239999771118164,-7.705999851226807 -0.42800000309944153,-4.798999786376953 0.972000002861023,-1.7589999437332153 C1.1929999589920044,-4.679999828338623 1.7610000371932983,-7.297999858856201 2.690000057220459,-9.704000473022461 C3.0209999084472656,-10.557000160217285 3.4240000247955322,-11.456000328063965 4.142000198364258,-12.244999885559082 C4.9730000495910645,-13.157999992370605 6.098999977111816,-13.744000434875488 7.230000019073486,-13.85200023651123 C8.588000297546387,-13.980999946594238 10.378000259399414,-13.345000267028809 11.100000381469727,-11.642999649047852 C11.63700008392334,-10.37399959564209 11.4350004196167,-8.961999893188477 11.20199966430664,-7.738999843597412 C10.869000434875488,-5.986000061035156 10.404000282287598,-4.21999979019165 9.954000473022461,-2.51200008392334 C9.50100040435791,-0.7910000085830688 9.032999992370605,0.9869999885559082 8.704000473022461,2.73799991607666 C8.505000114440918,3.802999973297119 8.354000091552734,4.892000198364258 8.208000183105469,5.945000171661377 C8.135000228881836,6.478000164031982 8.057999610900879,7.03000020980835 7.97599983215332,7.572999954223633 C7.785999774932861,8.835000038146973 7.5329999923706055,10.321999549865723 7.103000164031982,11.795000076293945 C7.083000183105469,11.861000061035156 7.064000129699707,11.942000389099121 7.043000221252441,12.031000137329102 C6.9019999504089355,12.621999740600586 6.690000057220459,13.513999938964844 5.836999893188477,13.789999961853027 C5.798999786376953,13.802000045776367 5.76200008392334,13.812999725341797 5.723999977111816,13.821000099182129z M5.521999835968018,12.897000312805176 C5.521999835968018,12.897000312805176 5.521999835968018,12.897000312805176 5.521999835968018,12.897000312805176z"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,70.4874267578125,48.2577018737793)" opacity="0.02592096774200131" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,12.479000091552734,14.140999794006348)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="1.69" d=" M-4.139999866485596,9.779000282287598 C-4.744999885559082,9.583000183105469 -4.895999908447266,8.951000213623047 -4.994999885559082,8.531999588012695 C-5.011000156402588,8.468999862670898 -5.021999835968018,8.411999702453613 -5.035999774932861,8.364999771118164 C-5.3420000076293945,7.320000171661377 -5.521999835968018,6.264999866485596 -5.6570000648498535,5.370999813079834 C-5.715000152587891,4.985000133514404 -5.769999980926514,4.593999862670898 -5.821000099182129,4.216000080108643 C-5.925000190734863,3.4690001010894775 -6.0320000648498535,2.696000099182129 -6.173999786376953,1.940999984741211 C-6.406000137329102,0.699999988079071 -6.738999843597412,-0.5619999766349792 -7.059999942779541,-1.781999945640564 C-7.379000186920166,-2.993000030517578 -7.709000110626221,-4.245999813079834 -7.945000171661377,-5.488999843597412 C-8.109000205993652,-6.35699987411499 -8.253999710083008,-7.357999801635742 -7.872000217437744,-8.258000373840332 C-7.360000133514404,-9.46500015258789 -6.091000080108643,-9.916000366210938 -5.127999782562256,-9.824999809265137 C-4.324999809265137,-9.74899959564209 -3.5269999504089355,-9.333000183105469 -2.937999963760376,-8.6850004196167 C-2.428999900817871,-8.125 -2.1429998874664307,-7.48799991607666 -1.9079999923706055,-6.882999897003174 C-1.2489999532699585,-5.176000118255615 -0.847000002861023,-3.319999933242798 -0.6890000104904175,-1.2489999532699585 C0.30399999022483826,-3.4040000438690186 1.5779999494552612,-5.465000152587891 3.7269999980926514,-6.870999813079834 C4.705999851226807,-7.511000156402588 5.6539998054504395,-7.684999942779541 6.4710001945495605,-7.374000072479248 C7.265999794006348,-7.071000099182129 7.638999938964844,-6.415999889373779 7.789999961853027,-6.052999973297119 C8.253000259399414,-4.939000129699707 7.954999923706055,-3.825000047683716 7.609000205993652,-2.7780001163482666 C6.617000102996826,0.2280000001192093 5.070000171661377,2.875 3.01200008392334,5.086999893188477 C2.7090001106262207,5.4120001792907715 2.3919999599456787,5.730999946594238 2.068000078201294,6.035999774932861 C0.7059999704360962,7.316999912261963 -0.8460000157356262,8.416999816894531 -2.5450000762939453,9.303999900817871 C-2.5920000076293945,9.329000473022461 -2.6570000648498535,9.368000030517578 -2.7260000705718994,9.409000396728516 C-3.0850000381469727,9.625 -3.569000005722046,9.916000366210938 -4.059999942779541,9.802000045776367 C-4.085999965667725,9.795000076293945 -4.11299991607666,9.788000106811523 -4.139999866485596,9.779000282287598z M-3.9170000553131104,9.145999908447266 C-3.9170000553131104,9.145999908447266 -3.9149999618530273,9.145999908447266 -3.9149999618530273,9.145999908447266 C-3.9149999618530273,9.145999908447266 -3.9170000553131104,9.145999908447266 -3.9170000553131104,9.145999908447266z"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,17.32712173461914,58.11800003051758)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,39.720001220703125,40.4640007019043)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.437" d=" M31.128000259399414,0 C31.128000259399414,17.60300064086914 17.191999435424805,31.871999740600586 0,31.871999740600586 C-17.19099998474121,31.871999740600586 -31.128000259399414,17.60300064086914 -31.128000259399414,0 C-31.128000259399414,-17.601999282836914 -17.19099998474121,-31.871999740600586 0,-31.871999740600586 C17.191999435424805,-31.871999740600586 31.128000259399414,-17.601999282836914 31.128000259399414,0z"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,56.124610900878906,63.209999084472656)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,37.23400115966797,37.917999267578125)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.437" d=" M28.642000198364258,0 C28.642000198364258,16.195999145507812 15.817999839782715,29.326000213623047 -0.0010000000474974513,29.326000213623047 C-15.819000244140625,29.326000213623047 -28.641000747680664,16.195999145507812 -28.641000747680664,0 C-28.641000747680664,-16.195999145507812 -15.819000244140625,-29.326000213623047 -0.0010000000474974513,-29.326000213623047 C15.817999839782715,-29.326000213623047 28.642000198364258,-16.195999145507812 28.642000198364258,0z"></path>
                                </g>
                            </g>
                        </g>
                    </svg></div>

                <br>

                <h3>
                    Ceremonia </h3>

                <div class="info-col">

                    <div class="info-box">
                        <h6>Día</h6>
                        <p>Sábado 15 de Mayo - 17h</p>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" class="boton addeventatc" id="addeventatc1" title="" aria-haspopup="true" aria-expanded="false" tabindex="0" translate="no" data-loaded="true" style="visibility: visible;">

                            <span class="nameBtn atc_node notranslate">Agendar</span>

                            <span class="start atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="end atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="timezone atc_node notranslate">Europe/Madrid</span>
                            <span class="title atc_node notranslate">Boda de Manuel y Laura (Ceremonia)</span>

                        </a>
                    </div>

                    <div class="info-box">
                        <h6>Lugar</h6>
                        <p>Parroquia Nuestra Señora de Lujan</p>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" data-evento="Ceremonia" class="boton confirmar-asistencia">Confirmar asistencia</a>
                    </div>

                    <div class="info-box">
                        <h6>Dirección</h6>
                        <p>Av. Pergamino 203 - Barcelona</p>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" data-evento="Ceremonia" class="boton modal-como-llegar">¿Cómo llegar?</a>
                    </div>

                </div>

            </div>


            <div class=" col-md-6 col-fiesta text-center">

                <div class="anim-fiesta"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130 130" width="130" height="130" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                        <defs>
                            <clippath id="__lottie_element_108">
                                <rect width="130" height="130" x="0" y="0"></rect>
                            </clippath>
                        </defs>
                        <g clip-path="url(#__lottie_element_108)">
                            <g style="display: none;" transform="matrix(1,0,0,1,6.5,9.75)" opacity="0.007542025888919995">
                                <g opacity="1" transform="matrix(1,0,0,1,75.55999755859375,23.030000686645508)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M9.35200023651123,-2.2809998989105225 C9.166999816894531,-2.8489999771118164 8.673999786376953,-3.26200008392334 8.083000183105469,-3.3480000495910645 C8.083000183105469,-3.3480000495910645 3.4709999561309814,-4.019999980926514 3.4709999561309814,-4.019999980926514 C3.4709999561309814,-4.019999980926514 1.4149999618530273,-8.197999954223633 1.4149999618530273,-8.197999954223633 C0.9570000171661377,-8.97700023651123 -0.04600000008940697,-9.236000061035156 -0.824999988079071,-8.777000427246094 C-1.0640000104904175,-8.63599967956543 -1.2630000114440918,-8.437999725341797 -1.4049999713897705,-8.197999954223633 C-1.4049999713897705,-8.197999954223633 -3.4709999561309814,-4.019999980926514 -3.4709999561309814,-4.019999980926514 C-3.4709999561309814,-4.019999980926514 -8.083000183105469,-3.3480000495910645 -8.083000183105469,-3.3480000495910645 C-8.942000389099121,-3.2239999771118164 -9.536999702453613,-2.427999973297119 -9.413000106811523,-1.5700000524520874 C-9.36299991607666,-1.2280000448226929 -9.204000473022461,-0.9120000004768372 -8.956999778747559,-0.6700000166893005 C-8.956999778747559,-0.6700000166893005 -5.619999885559082,2.5829999446868896 -5.619999885559082,2.5829999446868896 C-5.619999885559082,2.5829999446868896 -6.406000137329102,7.176000118255615 -6.406000137329102,7.176000118255615 C-6.557000160217285,8.029999732971191 -5.986999988555908,8.845000267028809 -5.131999969482422,8.996000289916992 C-4.788000106811523,9.057000160217285 -4.433000087738037,9.001999855041504 -4.125,8.83899974822998 C-4.125,8.83899974822998 0.0010000000474974513,6.663000106811523 0.0010000000474974513,6.663000106811523 C0.0010000000474974513,6.663000106811523 4.125999927520752,8.833000183105469 4.125999927520752,8.833000183105469 C4.894000053405762,9.237000465393066 5.8429999351501465,8.940999984741211 6.247000217437744,8.17300033569336 C6.4079999923706055,7.867000102996826 6.464000225067139,7.515999794006348 6.406000137329102,7.176000118255615 C6.406000137329102,7.176000118255615 5.619999885559082,2.5829999446868896 5.619999885559082,2.5829999446868896 C5.619999885559082,2.5829999446868896 8.956000328063965,-0.6700000166893005 8.956000328063965,-0.6700000166893005 C9.383999824523926,-1.0889999866485596 9.538000106811523,-1.7130000591278076 9.35200023651123,-2.2809998989105225z"></path>
                                </g>
                            </g>
                            <g style="display: none;" transform="matrix(1,0,0,1,-12.5,-20)" opacity="0.007318369272892937">
                                <g opacity="1" transform="matrix(1,0,0,1,56.909000396728516,38.75400161743164)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M5.057000160217285,0 C5.057000160217285,2.7929999828338623 2.7929999828338623,5.057000160217285 0,5.057000160217285 C-2.7929999828338623,5.057000160217285 -5.057000160217285,2.7929999828338623 -5.057000160217285,0 C-5.057000160217285,-2.7920000553131104 -2.7929999828338623,-5.057000160217285 0,-5.057000160217285 C2.7929999828338623,-5.057000160217285 5.057000160217285,-2.7920000553131104 5.057000160217285,0z"></path>
                                </g>
                            </g>
                            <g style="display: none;" transform="matrix(1,0,0,1,8,7.5)" opacity="0.0034742132339523834">
                                <g opacity="1" transform="matrix(1,0,0,1,98.23699951171875,85.31300354003906)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M5.057000160217285,0 C5.057000160217285,2.7929999828338623 2.7929999828338623,5.057000160217285 0,5.057000160217285 C-2.7929999828338623,5.057000160217285 -5.057000160217285,2.7929999828338623 -5.057000160217285,0 C-5.057000160217285,-2.7929999828338623 -2.7929999828338623,-5.057000160217285 0,-5.057000160217285 C2.7929999828338623,-5.057000160217285 5.057000160217285,-2.7929999828338623 5.057000160217285,0z"></path>
                                </g>
                            </g>
                            <g style="display: none;" transform="matrix(1,0,0,1,9.500003814697266,4.5)" opacity="0.0014847305598455307">
                                <g opacity="1" transform="matrix(1,0,0,1,85.64399719238281,46.60100173950195)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-0.9639999866485596,-0.871999979019165 C-0.9639999866485596,-0.871999979019165 0.9639999866485596,0.871999979019165 0.9639999866485596,0.871999979019165"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,91.30599975585938,43.941001892089844)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-0.04399999976158142,-1.7879999876022339 C-0.04399999976158142,-1.7879999876022339 0.04399999976158142,1.7879999876022339 0.04399999976158142,1.7879999876022339"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M91.3479995727539,58.45899963378906 C91.3479995727539,58.45899963378906 91.3479995727539,61.78499984741211 91.3479995727539,61.78499984741211"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,96.86199951171875,57.849998474121094)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-1.1540000438690186,-1.1349999904632568 C-1.1540000438690186,-1.1349999904632568 1.1540000438690186,1.1349999904632568 1.1540000438690186,1.1349999904632568"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M97.88800048828125,52.356998443603516 C97.88800048828125,52.356998443603516 100.50399780273438,52.356998443603516 100.50399780273438,52.356998443603516"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,96.9729995727539,46.66899871826172)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-1.003000020980835,0.9779999852180481 C-1.003000020980835,0.9779999852180481 1.003000020980835,-0.9779999852180481 1.003000020980835,-0.9779999852180481"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,9.500003814697266,4.5)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,69.16699981689453,74.1520004272461)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d="M0 0"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,9.500003814697266,4.5)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,72.7030029296875,60.55099868774414)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d="M0 0"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,9.500003814697266,4.5)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(-0.9933285713195801,0.11531856656074524,-0.11531856656074524,-0.9933285713195801,53.858001708984375,59.505001068115234)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d="M0 0"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,9.500003814697266,4.5)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,43.04600143432617,48.16999816894531)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d="M0 0"></path>
                                </g>
                            </g>
                            <g transform="matrix(0.9204199910163879,0,0,0.8299999833106995,8.79580020904541,24.540000915527344)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,47.23099899291992,67.61399841308594)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-15.63599967956543,-22.611000061035156 C-15.63599967956543,-22.611000061035156 -27.988000869750977,-24.674999237060547 -21.011999130249023,-10.725000381469727 C-21.011999130249023,-10.725000381469727 -8.109000205993652,18.570999145507812 17.177000045776367,23.628000259399414 C17.177000045776367,23.628000259399414 27.988000869750977,24.674999237060547 21.542999267578125,11.519000053405762"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,33.63600158691406,79.23300170898438)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-15.468999862670898,-18.809999465942383 C-15.468999862670898,-18.809999465942383 -12.083000183105469,10.090999603271484 15.468999862670898,18.809999465942383"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,20.20199966430664,92.8290023803711)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-4.409999847412109,-13.758999824523926 C-4.409999847412109,-13.758999824523926 -6.888000011444092,7.829999923706055 6.888000011444092,13.758999824523926"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,37.63999938964844,102.40299987792969)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(175,133,102)" stroke-opacity="1" stroke-width="3.531" d=" M-26.767000198364258,-2.0920000076293945 C-26.767000198364258,-2.0920000076293945 -29.382999420166016,11.16100025177002 -29.382999420166016,11.16100025177002 C-29.382999420166016,11.16100025177002 29.382999420166016,-11.16100025177002 29.382999420166016,-11.16100025177002"></path>
                                </g>
                            </g>
                        </g>
                    </svg></div>

                <br>

                <h3>
                    Celebración </h3>

                <div class="info-col">

                    <div class="info-box">
                        <h6>Día</h6>
                        <p>Sábado 15 de Mayo - 20h</p>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" class="boton addeventatc" id="addeventatc2" title="" aria-haspopup="true" aria-expanded="false" tabindex="0" translate="no" data-loaded="true" style="visibility: visible;">
                            <span class="nameBtn atc_node notranslate">Agendar</span>

                            <span class="start atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="end atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="timezone atc_node notranslate">Europe/Madrid</span>
                            <span class="title atc_node notranslate">Boda de Manuel y Laura (Fiesta)</span>
                        </a>
                    </div>

                    <div class="info-box">
                        <h6>Lugar</h6>
                        <p>Salon de fiestas Avril</p>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" data-evento="Fiesta" class="boton confirmar-asistencia">Confirmar asistencia</a>
                    </div>

                    <div class="info-box">
                        <h6>Dirección</h6>
                        <p>Av. Los Reartes 12 - Barcelona</p>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" data-evento="Fiesta" class="boton modal-como-llegar">¿Cómo llegar?</a>
                    </div>

                </div>

            </div>


        </div>
    </div>
</section>

<!-- Galeria-->
<section class="galeria">


    <div class="container">


        <div class="row text-center d-flex justify-content-center align-items-center">

            <div class="content-galeria">

                <h2 class="title">Retratos de Nuestro Amor</h2>
                <p class="subtitle">Un minuto, un segundo, un instante que queda en la eternidad</p>

                <div class="anim-galeria"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 111 121" width="111" height="121" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                        <defs>
                            <clippath id="__lottie_element_53">
                                <rect width="111" height="121" x="0" y="0"></rect>
                            </clippath>
                        </defs>
                        <g clip-path="url(#__lottie_element_53)">
                            <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,69.58100128173828,37.60599899291992)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M7.617000102996826,11.065999984741211 C7.617000102996826,11.065999984741211 -7.618000030517578,11.065999984741211 -7.618000030517578,11.065999984741211 C-9.434000015258789,11.065999984741211 -10.904999732971191,9.593999862670898 -10.904999732971191,7.7779998779296875 C-10.904999732971191,7.7779998779296875 -10.904999732971191,-7.7769999504089355 -10.904999732971191,-7.7769999504089355 C-10.904999732971191,-9.593000411987305 -9.434000015258789,-11.065999984741211 -7.618000030517578,-11.065999984741211 C-7.618000030517578,-11.065999984741211 7.617000102996826,-11.065999984741211 7.617000102996826,-11.065999984741211 C9.432999610900879,-11.065999984741211 10.904999732971191,-9.593000411987305 10.904999732971191,-7.7769999504089355 C10.904999732971191,-7.7769999504089355 10.904999732971191,7.7779998779296875 10.904999732971191,7.7779998779296875 C10.904999732971191,9.593999862670898 9.432999610900879,11.065999984741211 7.617000102996826,11.065999984741211z"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,45.99800109863281,67.86699676513672)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M36.66899871826172,-5.685999870300293 C36.66899871826172,-5.685999870300293 36.66899871826172,-11.456999778747559 36.66899871826172,-11.456999778747559 C39.69200134277344,-11.531000137329102 42.12200164794922,-13.99899959564209 42.12200164794922,-17.040000915527344 C42.12200164794922,-17.040000915527344 42.12200164794922,-43.48500061035156 42.12200164794922,-43.48500061035156 C42.12200164794922,-46.57099914550781 39.61899948120117,-49.07400131225586 36.53300094604492,-49.07400131225586 C36.53300094604492,-49.07400131225586 10.633000373840332,-49.07400131225586 10.633000373840332,-49.07400131225586 C7.546000003814697,-49.07400131225586 5.044000148773193,-46.57099914550781 5.044000148773193,-43.48500061035156 C5.044000148773193,-43.48500061035156 5.044000148773193,-17.040000915527344 5.044000148773193,-17.040000915527344 C5.044000148773193,-13.95300006866455 7.546000003814697,-11.451000213623047 10.633000373840332,-11.451000213623047 C10.633000373840332,-11.451000213623047 11.859000205993652,-11.451000213623047 11.859000205993652,-11.451000213623047 C11.859000205993652,-11.451000213623047 11.859000205993652,-5.72599983215332 11.859000205993652,-5.72599983215332 C11.859000205993652,-5.72599983215332 -35.93199920654297,-5.72599983215332 -35.93199920654297,-5.72599983215332 C-39.803001403808594,-5.72599983215332 -42.93899917602539,-2.5869998931884766 -42.93899917602539,1.2829999923706055 C-42.93899917602539,1.2829999923706055 -42.93899917602539,42.064998626708984 -42.93899917602539,42.064998626708984 C-42.93899917602539,45.93600082397461 -39.803001403808594,49.07400131225586 -35.93199920654297,49.07400131225586 C-35.93199920654297,49.07400131225586 35.93199920654297,49.07400131225586 35.93199920654297,49.07400131225586 C39.801998138427734,49.07400131225586 42.93899917602539,45.93600082397461 42.93899917602539,42.064998626708984 C42.93899917602539,42.064998626708984 42.93899917602539,1.2829999923706055 42.93899917602539,1.2829999923706055 C42.93899917602539,-2.3380000591278076 40.19200134277344,-5.316999912261963 36.66899871826172,-5.685999870300293z"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,45.99800109863281,88.7239990234375)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M17.584999084472656,0.0010000000474974513 C17.584999084472656,9.711999893188477 9.711000442504883,17.584999084472656 -0.0010000000474974513,17.584999084472656 C-9.711999893188477,17.584999084472656 -17.584999084472656,9.711999893188477 -17.584999084472656,0.0010000000474974513 C-17.584999084472656,-9.711000442504883 -9.711999893188477,-17.584999084472656 -0.0010000000474974513,-17.584999084472656 C9.711000442504883,-17.584999084472656 17.584999084472656,-9.711000442504883 17.584999084472656,0.0010000000474974513z"></path>
                                </g>
                            </g>
                            <g transform="matrix(0,0,0,0,46.39699935913086,88.28099822998047)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,45.99800109863281,88.7239990234375)">
                                    <path fill="rgb(178,126,73)" fill-opacity="1" d=" M17.584999084472656,0.0010000000474974513 C17.584999084472656,9.711999893188477 9.711000442504883,17.584999084472656 -0.0010000000474974513,17.584999084472656 C-9.711999893188477,17.584999084472656 -17.584999084472656,9.711999893188477 -17.584999084472656,0.0010000000474974513 C-17.584999084472656,-9.711000442504883 -9.711999893188477,-17.584999084472656 -0.0010000000474974513,-17.584999084472656 C9.711000442504883,-17.584999084472656 17.584999084472656,-9.711000442504883 17.584999084472656,0.0010000000474974513z"></path>
                                </g>
                            </g>
                            <g style="display: block;" transform="matrix(1,0,0,1,0,0)" opacity="0.34970416666659304">
                                <g opacity="1" transform="matrix(1,0,0,1,38.15999984741211,16.53499984741211)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M-4.390999794006348,-3.194000005722046 C-4.390999794006348,-3.194000005722046 4.390999794006348,3.194000005722046 4.390999794006348,3.194000005722046"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,38.15999984741211,42.29899978637695)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M-4.390999794006348,3.194000005722046 C-4.390999794006348,3.194000005722046 4.390999794006348,-3.194000005722046 4.390999794006348,-3.194000005722046"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M30.224000930786133,29.426000595092773 C30.224000930786133,29.426000595092773 39.76599884033203,29.426000595092773 39.76599884033203,29.426000595092773"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,99.36000061035156,16.53499984741211)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M4.390999794006348,-3.194000005722046 C4.390999794006348,-3.194000005722046 -4.390999794006348,3.194000005722046 -4.390999794006348,3.194000005722046"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,99.36000061035156,42.29899978637695)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M4.390999794006348,3.194000005722046 C4.390999794006348,3.194000005722046 -4.390999794006348,-3.194000005722046 -4.390999794006348,-3.194000005722046"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3.681" d=" M107.29499816894531,29.426000595092773 C107.29499816894531,29.426000595092773 97.75299835205078,29.426000595092773 97.75299835205078,29.426000595092773"></path>
                                </g>
                            </g>
                            <g style="display: block;" transform="matrix(1,0,0,1,0,0)" opacity="0.09203461538454746">
                                <g opacity="1" transform="matrix(1,0,0,1,69.58100128173828,37.60599899291992)">
                                    <path fill="rgb(178,126,73)" fill-opacity="1" d=" M7.617000102996826,11.065999984741211 C7.617000102996826,11.065999984741211 -7.618000030517578,11.065999984741211 -7.618000030517578,11.065999984741211 C-9.434000015258789,11.065999984741211 -10.904999732971191,9.593999862670898 -10.904999732971191,7.7779998779296875 C-10.904999732971191,7.7779998779296875 -10.904999732971191,-7.7769999504089355 -10.904999732971191,-7.7769999504089355 C-10.904999732971191,-9.593000411987305 -9.434000015258789,-11.065999984741211 -7.618000030517578,-11.065999984741211 C-7.618000030517578,-11.065999984741211 7.617000102996826,-11.065999984741211 7.617000102996826,-11.065999984741211 C9.432999610900879,-11.065999984741211 10.904999732971191,-9.593000411987305 10.904999732971191,-7.7769999504089355 C10.904999732971191,-7.7769999504089355 10.904999732971191,7.7779998779296875 10.904999732971191,7.7779998779296875 C10.904999732971191,9.593999862670898 9.432999610900879,11.065999984741211 7.617000102996826,11.065999984741211z"></path>
                                </g>
                            </g>
                        </g>
                    </svg></div>

            </div>

        </div>

    </div>


    <div class="content-fotos">

        <div class="shadow-left"></div>
        <div class="shadow-right"></div>

        <div class="carrusel slick-initialized slick-slider slick-dotted">











            <!-- Impmrimo el bloque con la imagen -->

            <div class="slick-list draggable" style="padding: 0px 20px;">
                <div class="slick-track" style="opacity: 1; width: 5952px; transform: translate3d(-2976px, 0px, 0px); transition: transform 500ms ease 0s;">
                    <div class="slick-slide slick-cloned" data-slick-index="-4" id="" aria-hidden="true" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/1.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/1.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-cloned" data-slick-index="-3" id="" aria-hidden="true" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/2.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/2.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-cloned" data-slick-index="-2" id="" aria-hidden="true" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/3.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/3.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-cloned slick-center" data-slick-index="-1" id="" aria-hidden="true" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/4.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/4.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide" data-slick-index="0" aria-hidden="true" tabindex="-1" role="tabpanel" id="slick-slide00" aria-describedby="slick-slide-control00" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/1.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/1.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" role="tabpanel" id="slick-slide01" aria-describedby="slick-slide-control01" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/2.jpg" data-fancybox="galeria" tabindex="0">
                                <img src="./Boda de Manuel y Laura_files/2.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-active" data-slick-index="2" aria-hidden="false" tabindex="0" role="tabpanel" id="slick-slide02" aria-describedby="slick-slide-control02" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/3.jpg" data-fancybox="galeria" tabindex="0">
                                <img src="./Boda de Manuel y Laura_files/3.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-current slick-active slick-center" data-slick-index="3" aria-hidden="false" tabindex="0" role="tabpanel" id="slick-slide03" aria-describedby="slick-slide-control03" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/4.jpg" data-fancybox="galeria" tabindex="0">
                                <img src="./Boda de Manuel y Laura_files/4.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-cloned slick-active" data-slick-index="4" id="" aria-hidden="false" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/1.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/1.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-cloned" data-slick-index="5" id="" aria-hidden="true" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/2.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/2.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-cloned" data-slick-index="6" id="" aria-hidden="true" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/3.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/3.jpg" alt="">
                            </a>

                        </div>
                    </div>
                    <div class="slick-slide slick-cloned" data-slick-index="7" id="" aria-hidden="true" tabindex="-1" style="width: 496px;">
                        <div class="polaroid">

                            <a href="./Boda de Manuel y Laura_files/4.jpg" data-fancybox="galeria" tabindex="-1">
                                <img src="./Boda de Manuel y Laura_files/4.jpg" alt="">
                            </a>

                        </div>
                    </div>
                </div>
            </div>


            <!-- Impmrimo el bloque con la imagen -->




            <!-- Impmrimo el bloque con la imagen -->




            <!-- Impmrimo el bloque con la imagen -->





            <ul class="slick-dots" style="" role="tablist">
                <li class="" role="presentation"><button type="button" role="tab" id="slick-slide-control00" aria-controls="slick-slide00" aria-label="1 of 2" tabindex="-1">1</button></li>
                <li role="presentation" class=""><button type="button" role="tab" id="slick-slide-control01" aria-controls="slick-slide01" aria-label="2 of 2" tabindex="-1">2</button></li>
                <li role="presentation" class=""><button type="button" role="tab" id="slick-slide-control02" aria-controls="slick-slide02" aria-label="3 of 2" tabindex="0" aria-selected="true">3</button></li>
                <li role="presentation" class="slick-active"><button type="button" role="tab" id="slick-slide-control03" aria-controls="slick-slide03" aria-label="4 of 2" tabindex="-1">4</button></li>
            </ul>
        </div>

    </div>




</section>

<!-- Fiesta-->
<section class="fiesta">

    <div class="container">
        <div class="row text-center d-flex justify-content-center align-items-center">



            <div class="col-md-12">
                <h2 class="title">Fiesta</h2>
                <p class="subtitle">Hagamos juntos una fiesta única. Os dejamos algunos detalles a tener en cuenta.</p>
            </div>




            <!-- Canciones -->
            <div class="col-md-4 item-fiesta">


                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo03.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo03.png">
                    <img class="adorno adorno-1" src="./Boda de Manuel y Laura_files/flores_Grupo03.png" alt="">
                </picture>



                <div class="w-100 content-item-fiesta d-flex flex-column justify-content-between align-items-center">



                    <h3>Música</h3>

                    <div class="d-flex justify-content-center align-items-center content-anim-fiesta">
                        <div class="anim-musica"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 111 121" width="111" height="121" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                                <defs>
                                    <clippath id="__lottie_element_69">
                                        <rect width="111" height="121" x="0" y="0"></rect>
                                    </clippath>
                                </defs>
                                <g clip-path="url(#__lottie_element_69)">
                                    <g style="display: block;" transform="matrix(1,0,0,1,0,0)" opacity="1">
                                        <g opacity="1" transform="matrix(1,0,0,1,93.38200378417969,28.083999633789062)">
                                            <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M9.42300033569336,-1.8270000219345093 C4.723999977111816,-3.5840001106262207 2.6679999828338623,-8.164999961853027 1.8609999418258667,-10.739999771118164 C1.6059999465942383,-11.557000160217285 0.8579999804496765,-12.104999542236328 0,-12.104999542236328 C-0.8569999933242798,-12.104999542236328 -1.6059999465942383,-11.557000160217285 -1.8619999885559082,-10.739999771118164 C-2.6689999103546143,-8.164999961853027 -4.7230000495910645,-3.5840001106262207 -9.42300033569336,-1.8270000219345093 C-10.1899995803833,-1.5399999618530273 -10.6850004196167,-0.8240000009536743 -10.685999870300293,-0.0010000000474974513 C-10.685999870300293,0.8209999799728394 -10.1899995803833,1.5390000343322754 -9.42300033569336,1.8259999752044678 C-4.7230000495910645,3.5829999446868896 -2.6689999103546143,8.163000106811523 -1.8619999885559082,10.73799991607666 C-1.6059999465942383,11.555000305175781 -0.8569999933242798,12.104999542236328 0,12.104999542236328 C0.8579999804496765,12.104999542236328 1.6059999465942383,11.555000305175781 1.8609999418258667,10.73799991607666 C2.6679999828338623,8.163000106811523 4.723999977111816,3.5829999446868896 9.42300033569336,1.8259999752044678 C10.190999984741211,1.5390000343322754 10.685999870300293,0.8209999799728394 10.685999870300293,-0.0010000000474974513 C10.685999870300293,-0.8240000009536743 10.1899995803833,-1.5399999618530273 9.42300033569336,-1.8270000219345093z"></path>
                                        </g>
                                    </g>
                                    <g style="display: block;" transform="matrix(1,0,0,1,0,0)" opacity="1">
                                        <g opacity="1" transform="matrix(1,0,0,1,70.65299987792969,39.2599983215332)">
                                            <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M-7.0229997634887695,1.6990000009536743 C-3.744999885559082,2.924999952316284 -2.299999952316284,6.151000022888184 -1.7330000400543213,7.965000152587891 C-1.49399995803833,8.72599983215332 -0.7979999780654907,9.236000061035156 -0.0010000000474974513,9.236000061035156 C0.796999990940094,9.236000061035156 1.4930000305175781,8.72599983215332 1.7319999933242798,7.965000152587891 C2.2990000247955322,6.151000022888184 3.743000030517578,2.9260001182556152 7.0229997634887695,1.6990000009536743 C7.736999988555908,1.4320000410079956 8.199000358581543,0.7649999856948853 8.199999809265137,0.0010000000474974513 C8.199999809265137,-0.7639999985694885 7.736999988555908,-1.430999994277954 7.0229997634887695,-1.6990000009536743 C3.743000030517578,-2.924999952316284 2.299999952316284,-6.151000022888184 1.7319999933242798,-7.965000152587891 C1.4930000305175781,-8.725000381469727 0.796999990940094,-9.236000061035156 -0.0010000000474974513,-9.236000061035156 C-0.7979999780654907,-9.236000061035156 -1.49399995803833,-8.725000381469727 -1.7330000400543213,-7.965000152587891 C-2.3010001182556152,-6.151000022888184 -3.74399995803833,-2.9260001182556152 -7.0229997634887695,-1.6990000009536743 C-7.736999988555908,-1.4320000410079956 -8.199999809265137,-0.7639999985694885 -8.199999809265137,0.0010000000474974513 C-8.199000358581543,0.7649999856948853 -7.736999988555908,1.4320000410079956 -7.0229997634887695,1.6990000009536743z"></path>
                                        </g>
                                    </g>
                                    <g style="display: block;" transform="matrix(1,0,0,1,0,0)" opacity="1">
                                        <g opacity="1" transform="matrix(1,0,0,1,29.084999084472656,88.52799987792969)">
                                            <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M9.42300033569336,-1.8270000219345093 C4.723999977111816,-3.5840001106262207 2.6689999103546143,-8.164999961853027 1.8619999885559082,-10.739999771118164 C1.6069999933242798,-11.557000160217285 0.8579999804496765,-12.104999542236328 0.0010000000474974513,-12.104999542236328 C0.0010000000474974513,-12.104999542236328 0,-12.104999542236328 0,-12.104999542236328 C-0.8569999933242798,-12.104999542236328 -1.6050000190734863,-11.557000160217285 -1.8619999885559082,-10.739999771118164 C-2.6679999828338623,-8.164999961853027 -4.7230000495910645,-3.5840001106262207 -9.42199993133545,-1.8270000219345093 C-10.189000129699707,-1.5399999618530273 -10.6850004196167,-0.8230000138282776 -10.6850004196167,-0.0010000000474974513 C-10.685999870300293,0.8209999799728394 -10.1899995803833,1.5390000343322754 -9.42199993133545,1.8259999752044678 C-4.7230000495910645,3.5829999446868896 -2.6679999828338623,8.163999557495117 -1.8619999885559082,10.73799991607666 C-1.6050000190734863,11.557000160217285 -0.8569999933242798,12.104999542236328 0.0010000000474974513,12.104999542236328 C0.8579999804496765,12.104999542236328 1.6069999933242798,11.557000160217285 1.8619999885559082,10.73799991607666 C2.6689999103546143,8.163999557495117 4.723999977111816,3.5829999446868896 9.42300033569336,1.8259999752044678 C10.190999984741211,1.5390000343322754 10.685999870300293,0.8209999799728394 10.685999870300293,-0.0010000000474974513 C10.685999870300293,-0.8230000138282776 10.1899995803833,-1.5399999618530273 9.42300033569336,-1.8270000219345093z"></path>
                                        </g>
                                    </g>
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,70.74500274658203,90.83399963378906)">
                                            <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M31.590999603271484,-22.299999237060547 C31.08099937438965,-22.95800018310547 30.31399917602539,-23.375999450683594 29.485000610351562,-23.44700050354004 C29.485000610351562,-23.44700050354004 -6.922999858856201,-26.565000534057617 -6.922999858856201,-26.565000534057617 C-8.458999633789062,-26.695999145507812 -9.866000175476074,-25.608999252319336 -10.123000144958496,-24.08799934387207 C-10.305999755859375,-23.007999420166016 -10.48900032043457,-21.929000854492188 -10.67199993133545,-20.849000930786133 C-11.27299976348877,-17.299999237060547 -15.305999755859375,6.492000102996826 -15.378000259399414,6.915999889373779 C-15.522000312805176,7.77400016784668 -16.0049991607666,7.5229997634887695 -16.82200050354004,7.428999900817871 C-17.375999450683594,7.366000175476074 -17.934999465942383,7.335999965667725 -18.493000030517578,7.341000080108643 C-19.63599967956543,7.35099983215332 -20.775999069213867,7.499000072479248 -21.884000778198242,7.776000022888184 C-28.204999923706055,9.35099983215332 -32.31399917602539,14.779000282287598 -31.04400062561035,19.874000549316406 C-30.41200065612793,22.409000396728516 -28.584999084472656,24.461999893188477 -25.899999618530273,25.65399932861328 C-24.340999603271484,26.34600067138672 -22.597000122070312,26.695999145507812 -20.795000076293945,26.695999145507812 C-19.63599967956543,26.695999145507812 -18.45199966430664,26.551000595092773 -17.277999877929688,26.257999420166016 C-14.651000022888184,25.60300064086914 -12.166000366210938,24.211999893188477 -10.366999626159668,22.17099952697754 C-8.571000099182129,20.131999969482422 -8.074000358581543,17.84600067138672 -7.633999824523926,15.24899959564209 C-7.46999979019165,14.279999732971191 -2.9049999713897705,-12.638999938964844 -2.815000057220459,-13.086999893188477 C-2.683000087738037,-13.73799991607666 -2.315000057220459,-13.637999534606934 -1.7410000562667847,-13.59000015258789 C-0.9399999976158142,-13.520999908447266 20.53499984741211,-11.680999755859375 21.159000396728516,-11.628999710083008 C21.360000610351562,-11.611000061035156 21.606000900268555,-11.548999786376953 21.562999725341797,-11.295000076293945 C21.361000061035156,-10.10099983215332 18.54199981689453,6.616000175476074 18.493000030517578,6.817999839782715 C18.327999114990234,7.491000175476074 17.466999053955078,7.072999954223633 16.986000061035156,7.020999908447266 C16.44700050354004,6.9629998207092285 15.904999732971191,6.939000129699707 15.36400032043457,6.946000099182129 C14.23799991607666,6.958000183105469 13.114999771118164,7.10699987411499 12.02299976348877,7.379000186920166 C9.024999618530273,8.12600040435791 6.421999931335449,9.751999855041504 4.693999767303467,11.958999633789062 C2.88100004196167,14.272000312805176 2.2320001125335693,16.941999435424805 2.86299991607666,19.476999282836914 C3.8970000743865967,23.625 8.180999755859375,26.29400062561035 13.14799976348877,26.29400062561035 C14.281999588012695,26.29400062561035 15.45300006866455,26.155000686645508 16.628999710083008,25.86199951171875 C20.96299934387207,24.781999588012695 24.437000274658203,21.816999435424805 25.601999282836914,18.243999481201172 C26.163000106811523,16.520999908447266 31.823999404907227,-17.902000427246094 32.00299835205078,-18.95800018310547 C32.06100082397461,-19.29599952697754 32.117000579833984,-19.634000778198242 32.17499923706055,-19.972999572753906 C32.31399917602539,-20.79400062561035 32.10100173950195,-21.642000198364258 31.590999603271484,-22.299999237060547z"></path>
                                        </g>
                                    </g>
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,31.030000686645508,44.19499969482422)">
                                            <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M27.599000930786133,5.492000102996826 C27.1200008392334,2.4719998836517334 22.238000869750977,-28.26300048828125 22.007999420166016,-29.711999893188477 C21.87700080871582,-30.534000396728516 21.405000686645508,-31.268999099731445 20.711999893188477,-31.729999542236328 C20.018999099731445,-32.191001892089844 19.158000946044922,-32.34299850463867 18.349000930786133,-32.14500045776367 C18.349000930786133,-32.14500045776367 -17.14900016784668,-23.475000381469727 -17.14900016784668,-23.475000381469727 C-18.64699935913086,-23.110000610351562 -19.631000518798828,-21.628999710083008 -19.389999389648438,-20.104999542236328 C-19.368999481201172,-19.972000122070312 -14.508999824523926,10.689000129699707 -14.468999862670898,10.958999633789062 C-14.340999603271484,11.831999778747559 -15.005000114440918,11.755999565124512 -15.701000213623047,11.906999588012695 C-16.236000061035156,12.022000312805176 -16.763999938964844,12.170999526977539 -17.281999588012695,12.350000381469727 C-18.363000869750977,12.722999572753906 -19.398000717163086,13.229000091552734 -20.361000061035156,13.845999717712402 C-25.847999572753906,17.35700035095215 -28.009000778198242,23.812000274658203 -25.179000854492188,28.236000061035156 C-23.770000457763672,30.437000274658203 -21.382999420166016,31.79800033569336 -18.45800018310547,32.07099914550781 C-15.529000282287598,32.34299850463867 -12.557999610900879,31.466999053955078 -10.095000267028809,29.889999389648438 C-7.574999809265137,28.277999877929688 -5.494999885559082,25.856000900268555 -4.545000076293945,22.9950008392334 C-4.301000118255615,22.261999130249023 -4.135000228881836,21.50200080871582 -4.065000057220459,20.73200035095215 C-4.000999927520752,20.045000076293945 -4.021999835968018,19.363000869750977 -4.1020002365112305,18.68000030517578 C-4.197999954223633,17.849000930786133 -8.89799976348877,-11.564000129699707 -8.970999717712402,-12.032999992370605 C-9.045000076293945,-12.496000289916992 -9.017000198364258,-12.609000205993652 -8.54699993133545,-12.722999572753906 C-7.409999847412109,-13.00100040435791 13.897000312805176,-18.204999923706055 14.093999862670898,-18.253000259399414 C14.510000228881836,-18.354999542236328 14.697999954223633,-18.25200080871582 14.765999794006348,-17.823999404907227 C15.29699993133545,-14.468999862670898 17.434999465942383,-0.9729999899864197 17.5310001373291,-0.367000013589859 C17.69700050354004,0.6800000071525574 17.099000930786133,0.5299999713897705 16.27199935913086,0.7110000252723694 C15.722000122070312,0.8309999704360962 15.178999900817871,0.9869999885559082 14.647000312805176,1.1740000247955322 C13.593999862670898,1.5449999570846558 12.585000038146973,2.0420000553131104 11.644000053405762,2.6429998874664307 C6.5329999923706055,5.914000034332275 4.311999797821045,11.73799991607666 6.321000099182129,16.09600067138672 C6.321000099182129,16.09600067138672 6.639999866485596,16.929000854492188 7.468999862670898,17.891000747680664 C7.502999782562256,17.930999755859375 7.538000106811523,17.969999313354492 7.572999954223633,18.010000228881836 C9.14900016784668,19.784000396728516 12.17300033569336,21.983999252319336 16.885000228881836,20.68000030517578 C18.625,20.354000091552734 20.344999313354492,19.68899917602539 21.910999298095703,18.687000274658203 C24.172000885009766,17.240999221801758 26.069000244140625,15.154000282287598 27.128000259399414,12.673999786376953 C27.614999771118164,11.53600025177002 27.923999786376953,10.315999984741211 27.965999603271484,9.076000213623047 C28.009000778198242,7.815999984741211 27.79599952697754,6.736000061035156 27.599000930786133,5.492000102996826z"></path>
                                        </g>
                                    </g>
                                </g>
                            </svg></div>
                    </div>


                    <p>
                        ¿Cuál es la canción que no debe faltar en la playlist de la fiesta? </p>

                    <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" class="boton sugerir-cancion">Sugerir canción</a>


                </div>

            </div>




            <!-- Dress Code -->
            <div class="col-md-4 item-fiesta">

                <div class="w-100 content-item-fiesta d-flex flex-column justify-content-between align-items-center">

                    <h3>Dress Code</h3>

                    <div class="d-flex justify-content-center align-items-center content-anim-fiesta">
                        <div class="anim-vestuario"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 76" width="150" height="76" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                                <defs>
                                    <clippath id="__lottie_element_85">
                                        <rect width="150" height="76" x="0" y="0"></rect>
                                    </clippath>
                                </defs>
                                <g clip-path="url(#__lottie_element_85)">
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,100.25499725341797,27.170000076293945)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.141" d="M0 0"></path>
                                        </g>
                                        <g opacity="1" transform="matrix(1,0,0,1,101.54000091552734,48.047000885009766)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.141" d="M0 0"></path>
                                        </g>
                                    </g>
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,49.58300018310547,27.170000076293945)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.141" d="M0 0"></path>
                                        </g>
                                        <g opacity="1" transform="matrix(1,0,0,1,48.29800033569336,48.047000885009766)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.141" d="M0 0"></path>
                                        </g>
                                    </g>
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,89.24700164794922,37.702999114990234)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.141" d="M0 0"></path>
                                        </g>
                                    </g>
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,60.685001373291016,37.513999938964844)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.141" d="M0 0"></path>
                                        </g>
                                    </g>
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,74.91899871826172,36.944000244140625)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.141" d=" M-10.611000061035156,16.131999969482422 C-10.611000061035156,16.131999969482422 11.196999549865723,16.131999969482422 11.196999549865723,16.131999969482422 C11.196999549865723,16.131999969482422 30.176000595092773,33.78099822998047 52.000999450683594,35.68000030517578 C52.000999450683594,35.68000030517578 68.7020034790039,38.715999603271484 70.5999984741211,26.3799991607666 C70.5999984741211,26.3799991607666 72.91000366210938,16.437999725341797 73.19400024414062,2.9760000705718994"></path>
                                        </g>
                                    </g>
                                </g>
                            </svg></div>
                    </div>

                    <p>
                        Una orientación para <br> tu vestuario </p>

                    <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" class="boton modal-vestuario">
                        Ver más </a>

                </div>

            </div>




            <!-- Notas -->
            <div class="col-md-4 item-fiesta">

                <div class="w-100 content-item-fiesta d-flex flex-column justify-content-between align-items-center">

                    <h3>Tips y Notas</h3>


                    <div class=" d-flex justify-content-center align-items-center content-anim-fiesta">
                        <div class="anim-tips"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 77 105" width="77" height="105" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                                <defs>
                                    <clippath id="__lottie_element_101">
                                        <rect width="77" height="105" x="0" y="0"></rect>
                                    </clippath>
                                </defs>
                                <g clip-path="url(#__lottie_element_101)">
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,37.7869987487793,57.72100067138672)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.12" d=" M-15.368000030517578,-0.34700000286102295 C-15.368000030517578,-0.34700000286102295 -4.968999862670898,9.822999954223633 -4.968999862670898,9.822999954223633 C-4.968999862670898,9.822999954223633 13.027999877929688,-7.561999797821045 15.161999702453613,-9.62399959564209"></path>
                                        </g>
                                    </g>
                                    <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,37.90299987792969,15.944000244140625)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.12" d=" M17.10300064086914,-6.309999942779541 C17.10300064086914,-6.309999942779541 17.10300064086914,-3.5209999084472656 17.10300064086914,-3.5209999084472656 C17.10300064086914,2.0309998989105225 12.60200023651123,6.5320000648498535 7.048999786376953,6.5320000648498535 C7.048999786376953,6.5320000648498535 -7.047999858856201,6.5320000648498535 -7.047999858856201,6.5320000648498535 C-12.60099983215332,6.5320000648498535 -17.10300064086914,2.0309998989105225 -17.10300064086914,-3.5209999084472656 C-17.10300064086914,-3.5209999084472656 -17.10300064086914,-6.5320000648498535 -17.10300064086914,-6.5320000648498535"></path>
                                        </g>
                                        <g opacity="1" transform="matrix(1,0,0,1,38.30699920654297,52.11600112915039)">
                                            <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3.12" d=" M28.604000091552734,-43.04499816894531 C28.604000091552734,-43.04499816894531 8.97700023651123,-43.04499816894531 8.97700023651123,-43.04499816894531 C8.211999893188477,-47.31399917602539 4.488999843597412,-50.55500030517578 0,-50.55500030517578 C-4.488999843597412,-50.55500030517578 -8.213000297546387,-47.31399917602539 -8.977999687194824,-43.04499816894531 C-8.977999687194824,-43.04499816894531 -28.604000091552734,-43.04499816894531 -28.604000091552734,-43.04499816894531 C-33.10200119018555,-43.04499816894531 -36.74700164794922,-39.39899826049805 -36.74700164794922,-34.902000427246094 C-36.74700164794922,-34.902000427246094 -36.74700164794922,42.41299819946289 -36.74700164794922,42.41299819946289 C-36.74700164794922,46.90999984741211 -33.10200119018555,50.55500030517578 -28.604000091552734,50.55500030517578 C-28.604000091552734,50.55500030517578 28.604000091552734,50.55500030517578 28.604000091552734,50.55500030517578 C33.10100173950195,50.55500030517578 36.74700164794922,46.90999984741211 36.74700164794922,42.41299819946289 C36.74700164794922,42.41299819946289 36.74700164794922,-34.902000427246094 36.74700164794922,-34.902000427246094 C36.74700164794922,-39.39899826049805 33.10100173950195,-43.04499816894531 28.604000091552734,-43.04499816894531z"></path>
                                        </g>
                                    </g>
                                </g>
                            </svg></div>
                    </div>


                    <p>
                        Información adicional <br> para tener en cuenta </p>


                    <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" class="boton  modal-tips">
                        + Info </a>

                </div>

            </div>



        </div>
    </div>
</section>

<!-- Regalos-->
<section class="regalos">




    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_A.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_A.png">
        <img class="adorno adorno-1 aos-init" data-aos="fade-right" data-aos-delay="500" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_A.png" alt="" loading="lazy">
    </picture>


    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_B.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_B.png">
        <img class="adorno adorno-2 aos-init" data-aos="fade-right" data-aos-delay="400" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_B.png" alt="" loading="lazy">
    </picture>


    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_C.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_C.png">
        <img class="adorno adorno-3 aos-init" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_C.png" alt="" loading="lazy">
    </picture>

    <picture>
        <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_D.webp">
        <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo02_D.png">
        <img class="adorno adorno-4 aos-init" data-aos="fade-right" data-aos-delay="500" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo02_D.png" alt="" loading="lazy">
    </picture>



    <div class="container">
        <div class="row text-center d-flex justify-content-center align-items-center">

            <h2 class="title">Regalos</h2>
            <p class="subtitle">Si deseáis regalarnos algo más que vuestra hermosa presencia...</p>

            <div class="w-100">

                <div class="anim-regalos"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 114" width="96" height="114" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                        <defs>
                            <clippath id="__lottie_element_136">
                                <rect width="96" height="114" x="0" y="0"></rect>
                            </clippath>
                        </defs>
                        <g clip-path="url(#__lottie_element_136)">
                            <g transform="matrix(1,0,0,0.765372633934021,0,25.947967529296875)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,48.388999938964844,86.24800109863281)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3" d=" M27.260000228881836,-23.70400047302246 C27.260000228881836,-23.70400047302246 27.260000228881836,16.000999450683594 27.260000228881836,16.000999450683594 C27.260000228881836,20.2549991607666 23.81100082397461,23.70400047302246 19.55699920654297,23.70400047302246 C19.55699920654297,23.70400047302246 -19.55500030517578,23.70400047302246 -19.55500030517578,23.70400047302246 C-23.809999465942383,23.70400047302246 -27.260000228881836,20.2549991607666 -27.260000228881836,16.000999450683594 C-27.260000228881836,16.000999450683594 -27.260000228881836,-23.70400047302246 -27.260000228881836,-23.70400047302246 C-27.260000228881836,-23.70400047302246 27.260000228881836,-23.70400047302246 27.260000228881836,-23.70400047302246z"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3" d=" M41.20399856567383,109.95099639892578 C41.20399856567383,109.95099639892578 41.20399856567383,62.395999908447266 41.20399856567383,62.395999908447266"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3" d=" M54.5369987487793,62.61800003051758 C54.5369987487793,62.61800003051758 54.5369987487793,109.95099639892578 54.5369987487793,109.95099639892578"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,0.765372633934021,0,26.175613403320312)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3" d=" M54.5369987487793,62.395999908447266 C54.5369987487793,62.395999908447266 54.5369987487793,44.84000015258789 54.5369987487793,44.84000015258789"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,47.5,53.50699996948242)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3" d=" M30.309999465942383,9.036999702453613 C30.309999465942383,9.036999702453613 -30.30900001525879,9.036999702453613 -30.30900001525879,9.036999702453613 C-33.534000396728516,9.036999702453613 -36.14799880981445,6.421999931335449 -36.14799880981445,3.197000026702881 C-36.14799880981445,3.197000026702881 -36.14799880981445,-3.197999954223633 -36.14799880981445,-3.197999954223633 C-36.14799880981445,-6.422999858856201 -33.534000396728516,-9.036999702453613 -30.30900001525879,-9.036999702453613 C-30.30900001525879,-9.036999702453613 30.309999465942383,-9.036999702453613 30.309999465942383,-9.036999702453613 C33.53499984741211,-9.036999702453613 36.14799880981445,-6.422999858856201 36.14799880981445,-3.197999954223633 C36.14799880981445,-3.197999954223633 36.14799880981445,3.197000026702881 36.14799880981445,3.197000026702881 C36.14799880981445,6.421999931335449 33.53499984741211,9.036999702453613 30.309999465942383,9.036999702453613z"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3" d=" M41.20399856567383,62.395999908447266 C41.20399856567383,62.395999908447266 41.20399856567383,44.84000015258789 41.20399856567383,44.84000015258789"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,0.765372633934021,0,26.175613403320312)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,47.64699935913086,33.92300033569336)">
                                    <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(178,126,73)" stroke-opacity="1" stroke-width="3" d=" M-0.6869999766349792,8.565999984741211 C-2.431999921798706,2.1489999294281006 -7.488999843597412,-10.281000137329102 -20.489999771118164,-10.281000137329102 C-25.785999298095703,-10.281000137329102 -29.073999404907227,-8.190999984741211 -29.073999404907227,-4.820000171661377 C-29.073999404907227,1.3029999732971191 -19.075000762939453,9.696999549865723 -0.25999999046325684,10.281000137329102 C-0.25999999046325684,10.281000137329102 0.25999999046325684,10.281000137329102 0.25999999046325684,10.281000137329102 C19.075000762939453,9.696999549865723 29.073999404907227,1.3029999732971191 29.073999404907227,-4.820000171661377 C29.073999404907227,-8.190999984741211 25.785999298095703,-10.281000137329102 20.489999771118164,-10.281000137329102 C7.63700008392334,-10.281000137329102 2.546999931335449,1.8669999837875366 0.746999979019165,8.343999862670898"></path>
                                </g>
                            </g>
                        </g>
                    </svg></div>

            </div>

            <br>

            <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" class="boton modal-regalos">Número de IBAN y lista de regalos</a>

        </div>
    </div>
</section>

<!-- Instagram-->
<section class="instagram">


    <div class="container">
        <div class="row text-center d-flex justify-content-center align-items-center">

            <h2 class="title">Compartimos este día junto a ti</h2>
            <p class="subtitle">Comparte tus fotos y vídeos de este hermoso día</p>

            <div class="w-100">

                <div class="anim-instagram"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 87 136" width="87" height="136" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                        <defs>
                            <clippath id="__lottie_element_146">
                                <rect width="87" height="136" x="0" y="0"></rect>
                            </clippath>
                        </defs>
                        <g clip-path="url(#__lottie_element_146)">
                            <g style="display: block;" transform="matrix(1,0,0,1,0,-7.728023529052734)" opacity="0.7728025000000692">
                                <g opacity="1" transform="matrix(1,0,0,1,23.05900001525879,31.052000045776367)">
                                    <path fill="rgb(255,255,255)" fill-opacity="1" d=" M12.784000396728516,-14 C12.784000396728516,-14 -12.782999992370605,-14 -12.782999992370605,-14 C-14.8149995803833,-14 -16.464000701904297,-12.352999687194824 -16.464000701904297,-10.319999694824219 C-16.464000701904297,-10.319999694824219 -16.464000701904297,5.690999984741211 -16.464000701904297,5.690999984741211 C-16.464000701904297,7.723999977111816 -14.8149995803833,9.371000289916992 -12.782999992370605,9.371000289916992 C-12.782999992370605,9.371000289916992 -5.416999816894531,9.371000289916992 -5.416999816894531,9.371000289916992 C-5.416999816894531,9.371000289916992 -1.7599999904632568,13.027999877929688 -1.7599999904632568,13.027999877929688 C-0.7889999747276306,14 0.7879999876022339,14 1.7599999904632568,13.027999877929688 C1.7599999904632568,13.027999877929688 5.416999816894531,9.371000289916992 5.416999816894531,9.371000289916992 C5.416999816894531,9.371000289916992 12.784000396728516,9.371000289916992 12.784000396728516,9.371000289916992 C14.815999984741211,9.371000289916992 16.464000701904297,7.723999977111816 16.464000701904297,5.690999984741211 C16.464000701904297,5.690999984741211 16.464000701904297,-10.319999694824219 16.464000701904297,-10.319999694824219 C16.464000701904297,-12.352999687194824 14.815999984741211,-14 12.784000396728516,-14z M5.208000183105469,-0.9020000100135803 C5.208000183105469,-0.9020000100135803 0.6299999952316284,3.5989999771118164 0.6299999952316284,3.5989999771118164 C0.44999998807907104,3.7760000228881836 0.21699999272823334,3.864000082015991 -0.01600000075995922,3.864000082015991 C-0.25099998712539673,3.864000082015991 -0.4869999885559082,3.7750000953674316 -0.6669999957084656,3.5969998836517334 C-0.6669999957084656,3.5969998836517334 -5.211999893188477,-0.9039999842643738 -5.211999893188477,-0.9039999842643738 C-5.869999885559082,-1.5509999990463257 -6.234000205993652,-2.4159998893737793 -6.234000205993652,-3.3359999656677246 C-6.234000205993652,-4.25600004196167 -5.869999885559082,-5.120999813079834 -5.210000038146973,-5.770999908447266 C-3.8570001125335693,-7.10099983215332 -1.656000018119812,-7.10099983215332 -0.30300000309944153,-5.770999908447266 C-0.30300000309944153,-5.770999908447266 -0.0010000000474974513,-5.473999977111816 -0.0010000000474974513,-5.473999977111816 C-0.0010000000474974513,-5.473999977111816 0.3009999990463257,-5.770999908447266 0.3009999990463257,-5.770999908447266 C1.6540000438690186,-7.10099983215332 3.8550000190734863,-7.10099983215332 5.208000183105469,-5.770999908447266 C5.86899995803833,-5.120999813079834 6.23199987411499,-4.25600004196167 6.23199987411499,-3.3359999656677246 C6.23199987411499,-2.4159998893737793 5.86899995803833,-1.5509999990463257 5.208000183105469,-0.9020000100135803z"></path>
                                </g>
                            </g>
                            <g style="display: none;" transform="matrix(1,0,0,1,0,-18.84389877319336)" opacity="0.013008333333268781">
                                <g opacity="1" transform="matrix(1,0,0,1,64.0459976196289,34.86899948120117)">
                                    <path fill="rgb(255,255,255)" fill-opacity="1" d=" M12.782999992370605,-14.00100040435791 C12.782999992370605,-14.00100040435791 -12.782999992370605,-14.00100040435791 -12.782999992370605,-14.00100040435791 C-14.8149995803833,-14.00100040435791 -16.464000701904297,-12.352999687194824 -16.464000701904297,-10.319999694824219 C-16.464000701904297,-10.319999694824219 -16.464000701904297,5.690999984741211 -16.464000701904297,5.690999984741211 C-16.464000701904297,7.7230000495910645 -14.8149995803833,9.371999740600586 -12.782999992370605,9.371999740600586 C-12.782999992370605,9.371999740600586 -5.415999889373779,9.371999740600586 -5.415999889373779,9.371999740600586 C-5.415999889373779,9.371999740600586 -1.7599999904632568,13.029000282287598 -1.7599999904632568,13.029000282287598 C-0.7879999876022339,14.00100040435791 0.7879999876022339,14.00100040435791 1.7599999904632568,13.029000282287598 C1.7599999904632568,13.029000282287598 5.415999889373779,9.371999740600586 5.415999889373779,9.371999740600586 C5.415999889373779,9.371999740600586 12.782999992370605,9.371999740600586 12.782999992370605,9.371999740600586 C14.8149995803833,9.371999740600586 16.464000701904297,7.7230000495910645 16.464000701904297,5.690999984741211 C16.464000701904297,5.690999984741211 16.464000701904297,-10.319999694824219 16.464000701904297,-10.319999694824219 C16.464000701904297,-12.352999687194824 14.8149995803833,-14.00100040435791 12.782999992370605,-14.00100040435791z M5.209000110626221,-0.9020000100135803 C5.209000110626221,-0.9020000100135803 0.6309999823570251,3.5999999046325684 0.6309999823570251,3.5999999046325684 C0.45100000500679016,3.7769999504089355 0.21799999475479126,3.865000009536743 -0.017000000923871994,3.865000009536743 C-0.25099998712539673,3.865000009536743 -0.4860000014305115,3.7760000228881836 -0.6660000085830688,3.5980000495910645 C-0.6660000085830688,3.5980000495910645 -5.210999965667725,-0.9039999842643738 -5.210999965667725,-0.9039999842643738 C-5.86899995803833,-1.5509999990463257 -6.232999801635742,-2.4159998893737793 -6.232999801635742,-3.3369998931884766 C-6.232999801635742,-4.256999969482422 -5.86899995803833,-5.119999885559082 -5.209000110626221,-5.769999980926514 C-3.8559999465942383,-7.099999904632568 -1.6540000438690186,-7.099999904632568 -0.3019999861717224,-5.769999980926514 C-0.3019999861717224,-5.769999980926514 0,-5.4730000495910645 0,-5.4730000495910645 C0,-5.4730000495910645 0.3019999861717224,-5.769999980926514 0.3019999861717224,-5.769999980926514 C1.6540000438690186,-7.099999904632568 3.8559999465942383,-7.099999904632568 5.209000110626221,-5.769999980926514 C5.86899995803833,-5.119999885559082 6.232999801635742,-4.256999969482422 6.232999801635742,-3.3369998931884766 C6.232999801635742,-2.4159998893737793 5.86899995803833,-1.5509999990463257 5.209000110626221,-0.9020000100135803z"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,-1,0)" opacity="0.024799999998702305" style="display: none;">
                                <g opacity="1" transform="matrix(1,0,0,1,42.99100112915039,92.53099822998047)">
                                    <path fill="rgb(255,255,255)" fill-opacity="1" d=" M0,-20.42799949645996 C-11.234999656677246,-20.42799949645996 -20.375,-11.263999938964844 -20.375,-0.0010000000474974513 C-20.375,11.262999534606934 -11.234999656677246,20.42799949645996 0,20.42799949645996 C11.234999656677246,20.42799949645996 20.375,11.262999534606934 20.375,-0.0010000000474974513 C20.375,-11.263999938964844 11.234999656677246,-20.42799949645996 0,-20.42799949645996z"></path>
                                </g>
                            </g>
                            <g transform="matrix(1,0,0,1,0,0)" opacity="1" style="display: block;">
                                <g opacity="1" transform="matrix(1,0,0,1,42.7869987487793,92.3270034790039)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M18.22100067138672,-39.83300018310547 C18.22100067138672,-39.83300018310547 -18.22100067138672,-39.83300018310547 -18.22100067138672,-39.83300018310547 C-30.082000732421875,-39.83300018310547 -39.731998443603516,-30.159000396728516 -39.731998443603516,-18.26799964904785 C-39.731998443603516,-18.26799964904785 -39.731998443603516,18.268999099731445 -39.731998443603516,18.268999099731445 C-39.731998443603516,30.15999984741211 -30.082000732421875,39.83300018310547 -18.22100067138672,39.83300018310547 C-18.22100067138672,39.83300018310547 18.222999572753906,39.83300018310547 18.222999572753906,39.83300018310547 C30.082000732421875,39.83300018310547 39.731998443603516,30.15999984741211 39.731998443603516,18.268999099731445 C39.731998443603516,18.268999099731445 39.731998443603516,-18.26799964904785 39.731998443603516,-18.26799964904785 C39.731998443603516,-30.159000396728516 30.08099937438965,-39.83300018310547 18.22100067138672,-39.83300018310547z"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,42.99100112915039,92.53099822998047)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M0,-20.42799949645996 C-11.234999656677246,-20.42799949645996 -20.375,-11.263999938964844 -20.375,-0.0010000000474974513 C-20.375,11.262999534606934 -11.234999656677246,20.42799949645996 0,20.42799949645996 C11.234999656677246,20.42799949645996 20.375,11.262999534606934 20.375,-0.0010000000474974513 C20.375,-11.263999938964844 11.234999656677246,-20.42799949645996 0,-20.42799949645996z"></path>
                                </g>
                                <g opacity="1" transform="matrix(1,0,0,1,66.48500061035156,68.05400085449219)">
                                    <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="3" d=" M0,-4.455999851226807 C-2.450000047683716,-4.455999851226807 -4.442999839782715,-2.4570000171661377 -4.442999839782715,-0.0010000000474974513 C-4.442999839782715,2.4560000896453857 -2.450000047683716,4.455999851226807 0,4.455999851226807 C2.450000047683716,4.455999851226807 4.442999839782715,2.4560000896453857 4.442999839782715,-0.0010000000474974513 C4.442999839782715,-2.4570000171661377 2.450000047683716,-4.455999851226807 0,-4.455999851226807z"></path>
                                </g>
                            </g>
                        </g>
                    </svg></div>

            </div>

            <div class="w-100">

                <a target="_blank" href="https://www.instagram.com/" class="hashtag">#manuelylaura</a>

            </div>

            <br>

            <a target="_blank" href="https://www.instagram.com/" class="boton">Ver en Instagram</a>

        </div>
    </div>
</section>

<!-- Footer-->
<section class="footer">
    <div class="container">

        <div class="row">



            <div class="col-md-6 col-nombres-footer d-flex justify-content-end align-items-center">

                <h4>
                    Manuel
                    <br class="d-md-none">
                    <span>&amp;</span>
                    <br class="d-md-none">
                    Laura
                </h4>

            </div>


            <div class="col-md-6 col-acciones-footer d-flex justify-content-center justify-content-md-center align-items-center">

                <ul>

                    <li>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" data-evento="Ceremonia" class="confirmar-asistencia">Confirmar asistencia a ceremonia</a>
                    </li>

                    <li>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" data-evento="Fiesta" class="confirmar-asistencia">Confirmar asistencia a fiesta</a>
                    </li>

                    <li>
                        <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" class="sugerir-cancion">Sugerir canción</a>
                    </li>

                    <li>
                        <div title="" class="addeventatc" id="addeventatc3" aria-haspopup="true" aria-expanded="false" tabindex="0" translate="no" data-loaded="true" style="visibility: visible;">

                            <span class="nameBtn atc_node notranslate">Agendar Fiesta</span>

                            <span class="start atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="end atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="timezone atc_node notranslate">Europe/Madrid</span>
                            <span class="title atc_node notranslate">Boda de Manuel y Laura (Fiesta)</span>

                        </div>
                    </li>

                    <li>
                        <div title="" class="addeventatc" id="addeventatc4" aria-haspopup="true" aria-expanded="false" tabindex="0" translate="no" data-loaded="true" style="visibility: visible;">

                            <span class="nameBtn atc_node notranslate">Agendar Ceremonia</span>

                            <span class="start atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="end atc_node notranslate">2023-09-05 01:32:55</span>
                            <span class="timezone atc_node notranslate">Europe/Madrid</span>
                            <span class="title atc_node notranslate">Boda de Manuel y Laura (Ceremonia)</span>

                        </div>
                    </li>

                </ul>

            </div>



        </div>

    </div>
</section>

<!-- Firma-->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-12">


                <p>
                    Desarrollado con <span class="heart">🧡</span> por <a href="https://fixdate.io/es/" target="_blank">Fixdate</a>
                </p>


                <!-- Modal cambio de idioma -->

                <p>
                    <img class="current-flag" width="20" height="20" src="./Boda de Manuel y Laura_files/es-ES.svg" alt="">
                    <a href="https://fixdate.io/es/modelo-invitacion/amanecer#" data-toggle="modal" data-target="#modal-lang">Cambiar país</a>
                </p>



            </div>
        </div>
    </div>
</footer>

<!-- Musica -->


<div id="controlador-musica">
    <div id="play-pause-music" data-estado-music="pause" class="music-anim-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="50" height="50" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
            <defs>
                <clippath id="__lottie_element_22">
                    <rect width="50" height="50" x="0" y="0"></rect>
                </clippath>
                <filter id="__lottie_element_30" filterUnits="objectBoundingBox" x="0%" y="0%" width="100%" height="100%">
                    <fecomponenttransfer in="SourceGraphic">
                        <fefunca type="table" tableValues="1.0 0.0"></fefunca>
                    </fecomponenttransfer>
                </filter>
                <mask id="__lottie_element_29" mask-type="alpha">
                    <g filter="url(#__lottie_element_30)">
                        <rect width="50" height="50" x="0" y="0" fill="#ffffff" opacity="0"></rect>
                        <g transform="matrix(1,0,0,1,102.25,-210.43701171875)" opacity="1" style="display: block;">
                            <g opacity="1" transform="matrix(1,0,0,1,-76.96900177001953,235.031005859375)">
                                <path fill="rgb(178,126,73)" fill-opacity="1" d=" M0,-15 C8.278499603271484,-15 15,-8.278499603271484 15,0 C15,8.278499603271484 8.278499603271484,15 0,15 C-8.278499603271484,15 -15,8.278499603271484 -15,0 C-15,-8.278499603271484 -8.278499603271484,-15 0,-15z"></path>
                            </g>
                        </g>
                    </g>
                </mask>
            </defs>
            <g clip-path="url(#__lottie_element_22)">
                <g mask="url(#__lottie_element_29)" style="display: block;">
                    <g transform="matrix(0.7199622988700867,0,0,0.7199622988700867,79.71405792236328,-148.94398498535156)" opacity="0.619089629984606">
                        <g opacity="1" transform="matrix(1,0,0,1,-76.01100158691406,241.23899841308594)">
                            <path fill="rgb(178,126,73)" fill-opacity="1" d=" M0,-18.73900032043457 C10.34205436706543,-18.73900032043457 18.73900032043457,-10.34205436706543 18.73900032043457,0 C18.73900032043457,10.34205436706543 10.34205436706543,18.73900032043457 0,18.73900032043457 C-10.34205436706543,18.73900032043457 -18.73900032043457,10.34205436706543 -18.73900032043457,0 C-18.73900032043457,-10.34205436706543 -10.34205436706543,-18.73900032043457 0,-18.73900032043457z"></path>
                        </g>
                    </g>
                </g>
                <g transform="matrix(1,0,0,1,102.25,-210.43701171875)" opacity="0.2" style="display: block;">
                    <g opacity="1" transform="matrix(1,0,0,1,-76.96900177001953,235.031005859375)">
                        <path fill="rgb(178,126,73)" fill-opacity="1" d=" M0,-15 C8.278499603271484,-15 15,-8.278499603271484 15,0 C15,8.278499603271484 8.278499603271484,15 0,15 C-8.278499603271484,15 -15,8.278499603271484 -15,0 C-15,-8.278499603271484 -8.278499603271484,-15 0,-15z"></path>
                    </g>
                </g>
                <g transform="matrix(0.9829871654510498,0,0,0.9829871654510498,18.10207748413086,18.119091033935547)" opacity="1" style="display: block;">
                    <g opacity="1" transform="matrix(1,0,0,1,6,6.631999969482422)">
                        <path fill="rgb(178,126,73)" fill-opacity="1" d=" M6,-6.175000190734863 C6,-6.328999996185303 5.923999786376953,-6.4679999351501465 5.816999912261963,-6.545000076293945 C5.696000099182129,-6.63700008392334 5.544000148773193,-6.6529998779296875 5.4070000648498535,-6.60699987411499 C5.4070000648498535,-6.60699987411499 -2.0480000972747803,-4.923999786376953 -2.0480000972747803,-4.923999786376953 C-2.2309999465942383,-4.86299991607666 -2.3529999256134033,-4.677000045776367 -2.3529999256134033,-4.492000102996826 C-2.3529999256134033,-4.492000102996826 -2.3529999256134033,2.1072306632995605 -2.3529999256134033,2.1072306632995605 C-2.7320001125335693,1.8142307996749878 -3.2039999961853027,1.6442307233810425 -3.7200000286102295,1.6442307233810425 C-4.98199987411499,1.6442307233810425 -6,2.6782307624816895 -6,3.95823073387146 C-6,5.2382307052612305 -4.98199987411499,6.27323055267334 -3.7200000286102295,6.27323055267334 C-2.503999948501587,6.27323055267334 -1.5010000467300415,5.284230709075928 -1.4559999704360962,4.0512309074401855 C-1.4559999704360962,4.0512309074401855 -1.4559999704360962,3.9882307052612305 -1.4559999704360962,3.9882307052612305 C-1.4559999704360962,3.9882307052612305 -1.4559999704360962,-2.7330000400543213 -1.4559999704360962,-2.7330000400543213 C-1.4559999704360962,-2.7330000400543213 5.0879998207092285,-4.10699987411499 5.0879998207092285,-4.10699987411499 C5.0879998207092285,-4.10699987411499 5.0879998207092285,1.4707692861557007 5.0879998207092285,1.4707692861557007 C4.708000183105469,1.1777691841125488 4.236999988555908,1.0087692737579346 3.7209999561309814,1.0087692737579346 C2.4590001106262207,1.0087692737579346 1.440000057220459,2.042769193649292 1.440000057220459,3.3227691650390625 C1.440000057220459,4.602769374847412 2.4590001106262207,5.6367692947387695 3.7209999561309814,5.6367692947387695 C4.936999797821045,5.6367692947387695 5.939000129699707,4.648769378662109 5.984000205993652,3.415769338607788 C5.984000205993652,3.415769338607788 5.984000205993652,3.352769136428833 5.984000205993652,3.352769136428833 C5.984000205993652,3.352769136428833 5.984000205993652,-6.175000190734863 5.984000205993652,-6.175000190734863 C5.984000205993652,-6.175000190734863 6,-6.175000190734863 6,-6.175000190734863z"></path>
                    </g>
                </g>
            </g>
        </svg></div>
</div>

<iframe id="player-musica-fondo" frameborder="0" allowfullscreen="1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" title="Ed Sheeran - Perfect (Lyrics)" width="10" height="10" src="./Boda de Manuel y Laura_files/saved_resource.html"></iframe>


<!-- Modal asistencia-->
<div id="modalAsistencia" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-md modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-content-2">

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.png">
                    <img class="adorno adorno-1 aos-init aos-animate" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo04.png" alt="" loading="">
                </picture>


                <div class="img-top-modal d-flex justify-content-center align-items-start">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <div class="white-circle-icon">
                        <img class="" src="./Boda de Manuel y Laura_files/img_circuloCeremonia.svg" alt="">
                    </div>

                </div>

                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                </div>

                <div class="modal-body">


                    <div class="formulario-content">

                        <form id="formAsistencia" action="https://fixdate.io/es/modelo-invitacion/amanecer">


                            <div class="form-group d-flex justify-content-around custom-control custom-radio custom-control-inline">
                                <div class="form-check">
                                    <input class="form-check-input custom-control-input" type="radio" name="asistencia" id="1" value="Si" checked="">
                                    <label class="form-check-label custom-control-label" for="1">
                                        Si! Confirmo </label>
                                </div>
                                <div class="form-check">
                                    <input class="custom-control-input" type="radio" name="asistencia" id="2" value="No">
                                    <label class="custom-control-label" for="2">
                                        No puedo :( </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" id="nombreAsistente" name="nombre" placeholder="Indica tu nombre completo">
                            </div>


                            <div class="form-group">
                                <textarea id="comentariosAsistente" class="form-control" name="comentarios" rows="2" placeholder="Indica algún dato importante"></textarea>
                            </div>

                            <input id="eventoAsistencia" type="hidden" name="evento" value="">
                            <input type="hidden" name="invitacion" value="">
                            <input type="hidden" name="token" value="">
                            <input type="hidden" name="lang" value="es">
                            <input type="hidden" name="country" value="es">

                        </form>

                    </div>

                    <div class="msj-content d-flex flex-column justify-content-center"></div>

                </div>

                <div class="modal-footer">
                    <button type="button" id="sendAsistencia" class="boton">Enviar</button>
                </div>

            </div>
        </div>


    </div>
</div>
<!-- Modal sugerir cancion-->
<div id="modalSugerirCancion" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-content-2">

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.png">
                    <img class="adorno adorno-1 aos-init aos-animate" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo04.png" alt="" loading="lazy">
                </picture>


                <div class="img-top-modal d-flex justify-content-center align-items-start">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <div class="white-circle-icon">
                        <img class="" src="./Boda de Manuel y Laura_files/img_circuloCanciones.svg" alt="">
                    </div>


                </div>

                <div class="modal-header">

                    <h5 class="modal-title">Sugerir Canción</h5>

                </div>

                <div class="modal-body">

                    <div class="formulario-content">

                        <form id="formSugerirCancion" action="https://fixdate.io/es/modelo-invitacion/amanecer">

                            <div class="form-group">
                                <input type="text" class="form-control" id="nombreSugerencia" name="nombre" placeholder="Tu nombre">
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" id="descripcionSugerencia" name="descripcion" placeholder="Nombre canción y autor">
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" id="linkSugerencia" name="link" placeholder="Si quieres pon el link de YouTube, Spotify, etc.">
                            </div>


                            <input type="hidden" name="invitacion" value="">
                            <input type="hidden" name="token" value="">
                            <input type="hidden" name="lang" value="es">
                            <input type="hidden" name="country" value="es">

                        </form>

                    </div>

                    <div class="msj-content d-flex flex-column justify-content-center"></div>

                </div>

                <div class="modal-footer">
                    <button type="button" id="sendSugerenciaCancion" class="boton">Sugerir canción</button>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- Modal vestuario-->
<div id="modalVestuario" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-content-2">

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.png">
                    <img class="adorno adorno-1 aos-init aos-animate" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo04.png" alt="" loading="lazy">
                </picture>



                <div class="img-top-modal d-flex justify-content-center align-items-start">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <div class="white-circle-icon">
                        <img class="" src="./Boda de Manuel y Laura_files/vestuario.svg" alt="">
                    </div>


                </div>



                <div class="modal-header">

                    <h5 class="modal-title">Dress Code</h5>

                </div>

                <div class="modal-body">

                    <p>Contenido Dress Code</p>

                </div>


                <div class="modal-footer"></div>


            </div>
        </div>
    </div>
</div>
<!-- Modal tips-->
<div id="modalTips" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-content-2">

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.png">
                    <img class="adorno adorno-1 aos-init aos-animate" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo04.png" alt="" loading="lazy">
                </picture>


                <div class="img-top-modal d-flex justify-content-center align-items-start">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <div class="white-circle-icon">
                        <img class="" src="./Boda de Manuel y Laura_files/tips.svg" alt="">
                    </div>

                </div>



                <div class="modal-header">

                    <h5 class="modal-title">Tips y Notas</h5>

                </div>

                <div class="modal-body">

                    <p>Contenido Tips y Notas</p>

                </div>


                <div class="modal-footer"></div>


            </div>
        </div>
    </div>
</div>
<!-- Modal regalos-->
<div id="modalRegalos" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-content-2">

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.png">
                    <img class="adorno adorno-1 aos-init aos-animate" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo04.png" alt="" loading="lazy">
                </picture>



                <div class="img-top-modal d-flex justify-content-center align-items-start">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <div class="white-circle-icon">
                        <img class="" src="./Boda de Manuel y Laura_files/img_circuloRegalo.svg" alt="">
                    </div>

                </div>



                <div class="modal-header">

                    <h5 class="modal-title">Regalos</h5>

                </div>

                <div class="modal-body">
                    <p>Contenido modal regalos</p>
                </div>

                <div class="modal-footer">
                </div>


            </div>
        </div>
    </div>
</div>
<!-- Modal mapa-->
<div id="modalMapa" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-content-2">

                <picture>
                    <source type="image/webp" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.webp">
                    <source type="image/png" srcset="https://fixdate.io/modelo-invitacion/58/img/flores_Grupo04.png">
                    <img class="adorno adorno-1 aos-init aos-animate" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000" data-aos-once="false" src="./Boda de Manuel y Laura_files/flores_Grupo04.png" alt="" loading="lazy">
                </picture>



                <div class="img-top-modal d-flex justify-content-center align-items-start">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                </div>


                <div class="modal-header">

                    <h5 class="modal-title"></h5>

                </div>

                <div class="modal-body">
                    <div id="googleMap">
                        <div style="height: 100%; width: 100%;">
                            <div style="overflow: hidden;"></div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <a class="boton ampliar-mapa" target="_blank" href="https://fixdate.io/es/modelo-invitacion/amanecer#">Ampliar mapa</a>
                </div>

            </div>

        </div>
    </div>
</div>
<!-- Modal musica inicio -->

<script>
    // Al cargar abro modal
    prealoaderOption.on("load", function() {
        $('#modalMusicaa').modal({
            backdrop: 'static'
        });
    });

    // Btn play music modal
    $('body').on('click', '#play-music-modal', function(e) {

        e.preventDefault();

        $('#play-pause-music').attr('data-estado-music', 'play');
        animMusicAnimIcon.play();
        player.playVideo();

        $('#modalMusica').modal('hide');

    });
</script>



<!-- Musica de fondo -->
<script>
    // 2. This code loads the IFrame Player API code asynchronously.
    var tag = document.createElement('script');

    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    // 3. This function creates an <iframe> (and YouTube player)
    //    after the API code downloads.
    var player;

    function onYouTubeIframeAPIReady() {
        player = new YT.Player('player-musica-fondo', {
            height: '10',
            width: '10',
            playerVars: {
                playlist: 'EH30RAXnRWs',
                loop: 1
            },
            events: {
                'onReady': onPlayerReady
            }
        });
    }

    // 4. The API will call this function when the video player is ready.
    function onPlayerReady(event) {
        event.target.setVolume(80);
        // event.target.playVideo();
    }

    // Pausar video
    function pauseVideo() {
        player.pauseVideo();
    }


    // Click en controlador musica
    $('body').on('click', '#play-pause-music', function(e) {

        e.preventDefault();

        // Estado actual
        var estadoMusic = $(this).attr('data-estado-music');

        // Pause music
        if (estadoMusic == 'pause') {
            $(this).attr('data-estado-music', 'play');
            animMusicAnimIcon.play();
            player.playVideo();

        }

        // Play music
        if (estadoMusic == 'play') {
            $(this).attr('data-estado-music', 'pause');
            player.pauseVideo();
            animMusicAnimIcon.stop();
        }


    });
</script>





<!-- Animaciones de diseño -->
<script>
    let svgContainerMusicAnimIcon = document.querySelector('.music-anim-icon');

    let animMusicAnimIcon = bodymovin.loadAnimation({
        wrapper: svgContainerMusicAnimIcon,
        animType: 'svg',
        autoplay: false,
        loop: true,
        path: _pathProducto + "img/music-player-icon.json"
    });
</script>





<!-- Animacion corazon seccion cuenta regresiva-->
<script>
    let svgContainerCorazonFalta = document.querySelector('.corazon-falta');

    let animCorazonFalta = bodymovin.loadAnimation({
        wrapper: svgContainerCorazonFalta,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/corazon-falta.json"
    });
</script>



<!-- Animacion anillos -->
<script>
    let svgContainerAnillos = document.querySelector('.anim-anillos');

    let animAnillos = bodymovin.loadAnimation({
        wrapper: svgContainerAnillos,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/img_ceremonia.json"
    });

    animAnillos.play();
</script>


<!-- Animacion galeria -->
<script>
    let svgContainerGaleria = document.querySelector('.anim-galeria');

    let animGaleria = bodymovin.loadAnimation({
        wrapper: svgContainerGaleria,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/json_camara.json"
    });

    animGaleria.play();
</script>


<!-- Animacion Musica -->
<script>
    let svgContainerMusica = document.querySelector('.anim-musica');

    let animMusica = bodymovin.loadAnimation({
        wrapper: svgContainerMusica,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/img_musica.json"
    });

    animMusica.play();
</script>



<!-- Animacion Vestuario -->
<script>
    let svgContainerVestuario = document.querySelector('.anim-vestuario');

    let animVestuario = bodymovin.loadAnimation({
        wrapper: svgContainerVestuario,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/vestuario.json"
    });

    animVestuario.play();
</script>


<!-- Animacion Tips -->
<script>
    let svgContainerTips = document.querySelector('.anim-tips');

    let animTips = bodymovin.loadAnimation({
        wrapper: svgContainerTips,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/tips.json"
    });

    animTips.play();
</script>


<!-- Animacion canciones -->
<script>
    let svgContainerFiesta = document.querySelector('.anim-fiesta');

    let animFiesta = bodymovin.loadAnimation({
        wrapper: svgContainerFiesta,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/img_fiesta.json"
    });

    animFiesta.play();
</script>


<!-- Animacion regalos -->
<script>
    let svgContainerRegalos = document.querySelector('.anim-regalos');

    let animRegalos = bodymovin.loadAnimation({
        wrapper: svgContainerRegalos,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/img_regalo.json"
    });

    animRegalos.play();
</script>



<!-- Animacion instagram -->
<script>
    let svgContainerInstagram = document.querySelector('.anim-instagram');

    let animInstagram = bodymovin.loadAnimation({
        wrapper: svgContainerInstagram,
        animType: 'svg',
        loop: true,
        path: _pathProducto + "img/img_instagram.json"
    });

    animInstagram.play();
</script>


<!-- Opciones carrusel galeria -->
<script>
    $('.carrusel').slick({
        lazyLoad: 'ondemand',
        autoplay: true,
        autoplaySpeed: 2000,
        centerMode: true,
        dots: true,
        centerPadding: '20px',
        slidesToShow: 3,
        prevArrow: false,
        nextArrow: false,
        responsive: [{
                breakpoint: 768,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '40px',
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '40px',
                    slidesToShow: 1
                }
            }
        ]
    });
</script>


<!-- Modal Confirmar asistencia -->
<script>
    // Abrir modal
    $('body').on('click', 'a.confirmar-asistencia', function(e) {

        e.preventDefault();

        // Remuevo mensajes de error anteriores
        $("#error-form").remove();

        var evento = $(this).attr('data-evento');

        $('#eventoAsistencia').val(evento);


        if (evento == 'Fiesta') {
            var titleModalAsistencia = lang_titleModalAsistenciaFiesta;
            var rutaImgModalAsistencia = _pathProducto + 'img/img_circuloFiesta.svg';
        }

        if (evento == 'Ceremonia') {
            var titleModalAsistencia = lang_titleModalAsistenciaCeremonia;
            var rutaImgModalAsistencia = _pathProducto + 'img/img_circuloCeremonia.svg';
        }

        $('#modalAsistencia .modal-title').text(titleModalAsistencia);
        $('#modalAsistencia .img-top-modal img').attr('src', rutaImgModalAsistencia);


        $('#modalAsistencia').modal({
            backdrop: 'static'
        })

    });


    // Validacion de form.
    function isOkAsistencia() {

        // Remuevo mensajes de error anteriores
        $("#error-form").remove();

        // Variables necesarias para la validacion
        var flag = true;
        var err = '';


        // Variables del form para validar.
        var asistenteName = $.trim($("#nombreAsistente").val());
        var asistenteComentarios = $.trim($("#comentariosAsistente").val());


        // Nombre
        if (asistenteName == '') {
            flag = false;
            err = lang_nombreRequerido;
        } else {
            if (asistenteName.length > 20) {
                flag = false;
                err = lang_caracteresNombreAsistencia;
            }
        }

        // Comentarios
        if (asistenteComentarios != '') {
            if (asistenteComentarios.length > 100) {
                flag = false;
                err = lang_caracteresComentariosAsistencia;
            }
        }

        // Si hay error
        if (flag === false) {

            // Imprimo el error
            $('#formAsistencia').after('<span id="error-form">' + err + '</span>');

        }

        // Retorno el estado de la validacion
        return flag;

    }


    // Enviar asistencia
    $('body').on('click', '#sendAsistencia', function(e) {

        e.preventDefault();


        if (isOkAsistencia()) //Form bien validado
        {

            // Load and disabled buttom.
            $("#sendAsistencia").text(lang_informandoAsistencia + "...");
            $("#sendAsistencia").prop("disabled", true);

            // Obtengo el Form.
            var formulario = $("#formAsistencia")[0];

            // Obtengo los datos del formulario
            var datos = new FormData(formulario);


            // Visualizar como viajan los datos
            // for (var pair of datos.entries()) {
            //   console.log(pair[0] + ", " + pair[1]);
            // }


            // Envio con fetch los datos mediante POST
            fetch(_pathApp + "producto/fetchs/confirmar-asistencia.php", {
                    method: "POST",
                    body: datos
                })
                // Promesas fetch
                .then(res => res.json())
                .then(data => {

                    // Si recibo error 
                    if (data.error === true) {

                        $("#sendAsistencia").text(lang_confirmarAsistencia);
                        $("#sendAsistencia").prop("disabled", false);

                        // Imprimo el error
                        $('#formAsistencia').after('<span id="error-form">' + data.desc + '</span>');
                    }

                    // Si no hay error 
                    if (data.error === false) {

                        $("#sendAsistencia").text(lang_confirmarAsistencia);
                        $("#sendAsistencia").prop("disabled", false);


                        // Oculto elementos del form y reseteo
                        $('#formAsistencia')[0].reset();
                        $('#modalAsistencia .formulario-content, #modalAsistencia .modal-footer, #modalAsistencia h5').hide();



                        // Acomodo el css para centrar mensaje
                        $('#modalAsistencia .modal-body').addClass('fix-height');

                        // Muestro mensaje de exito
                        $('#modalAsistencia .msj-content').html(
                            "<h5>" + lang_asistenciaMsjExito_1 + "</h5><p>" + lang_asistenciaMsjExito_2 + "</p>"
                        ).show();


                        // Cierro modal y vuelvo a activar form
                        setTimeout(function() {

                            $('#modalAsistencia').modal('hide');
                            $('#modalAsistencia .formulario-content, #modalAsistencia .modal-footer, #modalAsistencia h5').show();
                            $('#modalAsistencia .msj-content').html('').hide();
                            $('#modalAsistencia .modal-body').removeClass('fix-height');

                        }, 4000);

                    }

                });
        }


    });
</script>


<!-- Cuenta regresiva -->
<script>
    // Set the date we're counting down to
    var countDownDate = new Date(fechaCuentaRegresiva).getTime();

    // Update the count down every 1 second
    var x = setInterval(function() {

        // Get today's date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate - now;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"
        // document.getElementById("reloj").innerHTML = days + " días " + hours + "hs " +
        //   minutes + "m " + seconds + "s ";

        $("#dias .number").text(days);
        $("#horas .number").text(hours);
        $("#minutos .number").text(minutes);
        $("#segundos .number").text(seconds);



        // If the count down is finished, write some text
        if (distance < 0) {
            clearInterval(x);
            document.getElementById("reloj").innerHTML = '<p class="fin-cuenta">' +
                lang_textoFinalCuentaRegresiva + '</p>';
            $('.falta').text('');
        }
    }, 1000);
</script>


<!-- Modal sugerir cancion -->
<script>
    // Abrir modal
    $('body').on('click', 'a.sugerir-cancion', function(e) {

        e.preventDefault();

        // Remuevo mensajes de error anteriores
        $("#error-form").remove();

        $('#modalSugerirCancion').modal({
            backdrop: 'static'
        })

    });



    // Validacion de form.
    function isOkSugerirCancion() {


        // Remuevo mensajes de error anteriores
        $("#error-form").remove();

        // Variables necesarias para la validacion
        var flag = true;
        var err = '';


        // Variables del form para validar.
        var sugerenciaName = $.trim($("#nombreSugerencia").val());
        var sugerenciaDescription = $.trim($("#descripcionSugerencia").val());
        var sugerenciaLink = $.trim($("#linkSugerencia").val());



        // Descripcion
        if (sugerenciaDescription == '') {
            flag = false;
            err = lang_cancionRequerida;
        } else {
            if (sugerenciaDescription.length > 50) {
                flag = false;
                err = lang_caracteresCancionSugerencia;
            }
        }

        // Link
        if (sugerenciaLink != '') {

            if (!is_url(sugerenciaLink)) {
                flag = false;
                err = lang_linkIncorrecto;
            }
            if (sugerenciaLink.length > 250) {
                flag = false;
                err = lang_caracteresLinkSugerencia;
            }

        }

        // Nombre
        if (sugerenciaName == '') {
            flag = false;
            err = lang_nombreRequerido;
        } else {
            if (sugerenciaName.length > 20) {
                flag = false;
                err = lang_caracteresNombreSugerencia;
            }
        }


        // Si hay error
        if (flag === false) {

            // Imprimo el error
            $('#formSugerirCancion').after('<span id="error-form">' + err + '</span>');

        }

        // Retorno el estado de la validacion
        return flag;

    }



    // Enviar sugerencia
    $('body').on('click', '#sendSugerenciaCancion', function(e) {

        e.preventDefault();


        if (isOkSugerirCancion()) //Form bien validado
        {

            // Load and disabled buttom.
            $("#sendSugerenciaCancion").text(lang_enviandoSugerencia + "...");
            $("#sendSugerenciaCancion").prop("disabled", true);

            // Obtengo el Form.
            var formulario = $("#formSugerirCancion")[0];

            // Obtengo los datos del formulario
            var datos = new FormData(formulario);


            // Visualizar como viajan los datos
            for (var pair of datos.entries()) {
                console.log(pair[0] + ", " + pair[1]);
            }


            // Envio con fetch los datos mediante POST
            fetch(_pathApp + "producto/fetchs/sugerir-cancion.php", {
                    method: "POST",
                    body: datos
                })
                // Promesas fetch
                .then(res => res.json())
                .then(data => {

                    // Si recibo error 
                    if (data.error === true) {

                        $("#sendSugerenciaCancion").text(lang_sugerirCancion);
                        $("#sendSugerenciaCancion").prop("disabled", false);

                        // Imprimo el error
                        $('#formSugerirCancion').after('<span id="error-form">' + data.desc + '</span>');
                    }

                    // Si no hay error 
                    if (data.error === false) {

                        $("#sendSugerenciaCancion").text(lang_sugerirCancion);
                        $("#sendSugerenciaCancion").prop("disabled", false);


                        // Oculto elementos del form y reseteo
                        $('#formSugerirCancion')[0].reset();
                        $('#modalSugerirCancion .formulario-content, #modalSugerirCancion .modal-footer, #modalSugerirCancion h5').hide();


                        // Acomodo el css para centrar mensaje
                        $('#modalSugerirCancion .modal-body').addClass('fix-height');


                        // Muestro mensaje de exito

                        $('#modalSugerirCancion .msj-content').html(
                            "<h5>" + lang_sugerirCancionMsjExito_1 + "</h5><p>" + lang_sugerirCancionMsjExito_2 + "</p>"
                        ).show();


                        // Cierro modal y vuelvo a activar form
                        setTimeout(function() {

                            $('#modalSugerirCancion').modal('hide');
                            $('#modalSugerirCancion .formulario-content, #modalSugerirCancion .modal-footer, #modalSugerirCancion h5').show();
                            $('#modalSugerirCancion .msj-content').html('').hide();
                            $('#modalSugerirCancion .modal-body').removeClass('fix-height');

                        }, 4000);

                    }

                });
        }


    });
</script>


<!-- Modal Vestuario -->
<script>
    // Abrir modal
    $('body').on('click', 'a.modal-vestuario', function(e) {

        e.preventDefault();

        $('#modalVestuario').modal({
            backdrop: 'static'
        })

    });
</script>


<!-- Modal Tips -->
<script>
    // Abrir modal
    $('body').on('click', 'a.modal-tips', function(e) {

        e.preventDefault();

        $('#modalTips').modal({
            backdrop: 'static'
        })

    });
</script>


<!-- Modal regalos -->
<script>
    // Abrir modal
    $('body').on('click', 'a.modal-regalos', function(e) {

        e.preventDefault();

        $('#modalRegalos').modal({
            backdrop: 'static'
        })

    });
</script>



<!-- Modal como llegar -->
<script>
    // Abrir modal
    $('body').on('click', 'a.modal-como-llegar', function(e) {

        e.preventDefault();

        var evento = $(this).attr('data-evento');

        if (evento == 'Fiesta') {
            var titleModalMapa = lang_titleModalMapaFiesta;

            var latitudMapa = latitudFiesta;
            var longitudMapa = longitudFiesta;
        }

        if (evento == 'Ceremonia') {
            var titleModalMapa = lang_titleModalMapaCeremonia;

            var latitudMapa = latitudCeremonia;
            var longitudMapa = longitudCeremonia;
        }

        // Cambio titulo
        $('#modalMapa .modal-title').text(titleModalMapa);

        // Genero el link para ampliar mapa
        $('.ampliar-mapa').attr('href', 'https://www.google.com/maps/search/?api=1&query=' + latitudMapa + ',' + longitudMapa);

        // Cambio mapa
        initMap(latitudMapa, longitudMapa);

        $('#modalMapa').modal({
            backdrop: 'static'
        })

    });
</script>



<!-- Instagram parallax -->
<script>
    // Si el ancho es de Telefono
    if ($(window).width() < 768) {

        // Aceptar webp?
        if (support_format_webp()) {
            var imageInstagramParallax = 'img/instagram_mobile.webp';
        } else {
            var imageInstagramParallax = 'img/instagram_mobile.jpg';
        }

    } else {

        // Aceptar webp?
        if (support_format_webp()) {
            var imageInstagramParallax = 'img/instagram.webp';
        } else {
            var imageInstagramParallax = 'img/instagram.jpg';
        }

    }

    $('.instagram').parallax({
        imageSrc: _pathProducto + imageInstagramParallax
    });
</script>


<!-- Api Maps-->
<script async="" defer="" src="./Boda de Manuel y Laura_files/js">
</script>


<script>
    // Config map
    function initMap(latitud = 0, longitud = 0) {

        var myLatLng = {
            lat: latitud,
            lng: longitud
        };

        var mapOptions = {
            // How zoomed in you want the map to start at (always required)
            zoom: 15,
            scrollwheel: false,
            disableDefaultUI: false,

            // The latitude and longitude to center the map (always required)
            center: new google.maps.LatLng(latitud, longitud),

            // How you would like to style the map.
            // This is where you would paste any style found on Snazzy Maps.
            styles: [{
                    "featureType": "administrative",
                    "elementType": "labels.text.fill",
                    "stylers": [{
                        "color": "#6195a0"
                    }]
                },
                {
                    "featureType": "landscape",
                    "elementType": "all",
                    "stylers": [{
                        "color": "#f2f2f2"
                    }]
                },
                {
                    "featureType": "landscape",
                    "elementType": "geometry.fill",
                    "stylers": [{
                        "color": "#ffffff"
                    }]
                },
                {
                    "featureType": "poi",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "poi.park",
                    "elementType": "geometry.fill",
                    "stylers": [{
                            "color": "#e6f3d6"
                        },
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "road",
                    "elementType": "all",
                    "stylers": [{
                            "saturation": -100
                        },
                        {
                            "lightness": 45
                        },
                        {
                            "visibility": "simplified"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "simplified"
                    }]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry.fill",
                    "stylers": [{
                            "color": "#f4d2c5"
                        },
                        {
                            "visibility": "simplified"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "labels.text",
                    "stylers": [{
                        "color": "#4e4e4e"
                    }]
                },
                {
                    "featureType": "road.arterial",
                    "elementType": "geometry.fill",
                    "stylers": [{
                        "color": "#f4f4f4"
                    }]
                },
                {
                    "featureType": "road.arterial",
                    "elementType": "labels.text.fill",
                    "stylers": [{
                        "color": "#787878"
                    }]
                },
                {
                    "featureType": "road.arterial",
                    "elementType": "labels.icon",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "transit",
                    "elementType": "all",
                    "stylers": [{
                        "visibility": "off"
                    }]
                },
                {
                    "featureType": "water",
                    "elementType": "all",
                    "stylers": [{
                            "color": "#eaf6f8"
                        },
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry.fill",
                    "stylers": [{
                        "color": "#eaf6f8"
                    }]
                }
            ]

        };

        var mapElement = document.getElementById('googleMap');

        var map = new google.maps.Map(mapElement, mapOptions);

        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
        });

    }
</script>


<!-- AddEvent script -->
<?= $this->Html->script('atc.min.js') ?>

<!-- AddEvent Settings -->
<script type="text/javascript">
    window.addeventasync = function() {
        addeventatc.settings({

            css: false,

            appleical: {
                show: true,
                text: "Apple Calendar"
            },
            google: {
                show: true,
                text: "Google <em>(online)</em>"
            },
            office365: {
                show: true,
                text: "Office 365 <em>(online)</em>"
            },
            outlook: {
                show: true,
                text: "Outlook"
            },
            outlookcom: {
                show: true,
                text: "Outlook.com <em>(online)</em>"
            },
            yahoo: {
                show: true,
                text: "Yahoo <em>(online)</em>"
            },
            facebook: {
                show: true,
                text: "Facebook"
            }
        });
    };
</script>



<!-- Idiomas segun config de invitacion -->






<!-- Portada parallax -->
<script>
    if (device == 'mobile' || $(window).width() < 768) {

        // Aceptar webp?
        if (support_format_webp()) {
            var imageParallax = 'img/portada-mobile.webp';
        } else {
            var imageParallax = 'img/portada-mobile.jpg';
        }

    } else {

        // Aceptar webp?
        if (support_format_webp()) {
            var imageParallax = 'img/portada.webp';
        } else {
            var imageParallax = 'img/portada.jpg';
        }

    }

    $('.portada-picture').parallax({
        imageSrc: _pathProducto + imageParallax
    });
</script>









<div class="modal-backdrop fade show"></div>