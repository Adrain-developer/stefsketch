<h2><?= h($blogCategory->name) ?></h2>
<p>ID: <?= $blogCategory->id ?></p>
<p>Creado: <?= $blogCategory->created ?></p>
<p>Modificado: <?= $blogCategory->modified ?></p>