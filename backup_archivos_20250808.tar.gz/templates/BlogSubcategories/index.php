<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\BlogSubcategory> $blogSubcategories
 */
?>
<div class="blogSubcategories index content">
    <?= $this->Html->link(__('New Blog Subcategory'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Blog Subcategories') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($blogSubcategories as $blogSubcategory): ?>
                <tr>
                    <td><?= $this->Number->format($blogSubcategory->id) ?></td>
                    <td><?= h($blogSubcategory->name) ?></td>
                    <td><?= h($blogSubcategory->created) ?></td>
                    <td><?= h($blogSubcategory->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $blogSubcategory->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $blogSubcategory->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $blogSubcategory->id], ['confirm' => __('Are you sure you want to delete # {0}?', $blogSubcategory->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
