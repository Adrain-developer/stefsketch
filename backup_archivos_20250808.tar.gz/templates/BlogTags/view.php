<h2><?= h($blogTag->name) ?></h2>
<p>ID: <?= $blogTag->id ?></p>
<p>Creado: <?= $blogTag->created ?></p>
<p>Modificado: <?= $blogTag->modified ?></p>
