<?php
return [
    'day' => '1 día',
    'days' => '{0} días',
    'week' => '1 semana',
    'weeks' => '{0} semanas',
    'month' => '1 mes',
    'months' => '{0} meses',
    'year' => '1 año',
    'years' => '{0} años',
    'ago' => 'hace {0}',
    'on' => 'el {0}',
    'in' => 'en {0}',
];
